#include "EnemyAir.h"

EnemyAir::EnemyAir()
{
	acc = Vector3::ZERO;
	oscillate = true;
	oscillateCounter = 0;
}

void EnemyAir::advance(Ogre::Real elapsedTime)
{
	oscillateCounter += 10;
	// Only reconsider direction after completing two oscillations
	if (oscillateCounter == 370)
	{
		oscillateCounter = 10;

		Vector3 enemyPos = enemyNode->getWorldPosition();
		Vector3 playerPos = mSceneMgr->getRootSceneNode()->getChild("Player")->getWorldPosition();
		// Chase player only if flag is set and they're within range of enemy
		if (chasePlayer && (enemyPos.z - territoryRange <= playerPos.z) && (enemyPos.z + territoryRange >= playerPos.z))
		{
			// Turn around if enemy is facing other direction
			if ((velocity.z < 0 && playerPos.z > enemyPos.z) || (velocity.z > 0 && playerPos.z < enemyPos.z)) velocity.z *= -1;
		}
		// Do not go much beyond one's territory
		else if ((enemyPos.z < territoryCenter - territoryRange) && velocity.z < 0) velocity.z *= -1;
		else if ((enemyPos.z > territoryCenter + territoryRange) && velocity.z > 0) velocity.z *= -1;
	}

	velocity.y = sin(oscillateCounter*3.14/180);
	if(velocity != Vector3::ZERO) 
	{
		velocity = velocity + acc * 10 * elapsedTime;
		enemyNode->translate(velocity);
		if(enemyNode->getPosition().y < 100)
			enemyNode->setPosition(enemyNode->getPosition().x, 100,enemyNode->getPosition().z);
	}
}

void EnemyAir::setOscillation(bool yorn)
{
	oscillate = yorn;
}
#include "Enemy.h"
#include "Sound.h"

Enemy::Enemy()
{
	chasePlayer = true;
	isDead = false;
	territoryRange = 100;
	deadCount = 25;
	killSound = new Sound*[4];
	
}

Enemy::~Enemy()
{
	/*delete killSound[0];
	delete killSound[1];
	delete killSound[2];
	delete killSound[3];
	delete killSound;*/
}

int Enemy::checkCollision(Player *player)
{
	if(isDead)
		return 0;
	Vector3 pPos = player->getNode()->getWorldPosition();
	Vector3 ePos = enemyNode->getWorldPosition();
	if (ePos.positionEquals(pPos,enemyRadius))
	{
    if (player->isInvincible()) {
      kill();
      // Fall off stage instead of normal death
      //dieFromInvincibility();
    }
	if (pPos.y - 2 > ePos.y && player->negVelocity())
		{  // Collision from above
      kill();
			return 2;
		}
		return 1;
	}
	else
	{
		return 0;
	}
}

SceneNode* Enemy::getNode()
{
	return enemyNode;
}

bool Enemy::getChasePlayer()
{
	return chasePlayer;
}

void Enemy::kill()
{
	isDead = true;
	
	killSound[(rand()%4)]->Play();

	velocity.z = 0;
	acc.z = 0;
	squish();
}

void Enemy::setChasePlayer(bool chase)
{
	chasePlayer = chase;
}

void Enemy::setTerritoryRange(int range)
{
	territoryRange = range;
}

void Enemy::squish()
{
	enemyNode->scale(Vector3(1,.5,1));
}

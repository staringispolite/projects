#include "EnemyLand.h"

EnemyLand::EnemyLand()
{
	acc = Vector3(0,-5,0);
}

void EnemyLand::advance(Ogre::Real elapsedTime)
{
	if(!isDead) {
		if(isAnimated)
			mAnimationState->addTime( elapsedTime );
		Vector3 enemyPos = enemyNode->getWorldPosition();
		Vector3 playerPos = mSceneMgr->getRootSceneNode()->getChild("Player")->getWorldPosition();
		// Chase player only if flag is set and they're within range of enemy
		if (chasePlayer && (enemyPos.z - territoryRange <= playerPos.z) && (enemyPos.z + territoryRange >= playerPos.z))
		{
			if ((velocity.z < 0 && playerPos.z > enemyPos.z) || (velocity.z > 0 && playerPos.z < enemyPos.z)) velocity.z *= -1;
		}
		// Do not go much beyond one's territory
		else if ((enemyPos.z <= territoryCenter - territoryRange) && velocity.z < 0) velocity.z *= -1;
		else if ((enemyPos.z >= territoryCenter + territoryRange) && velocity.z > 0) velocity.z *= -1;

		if(velocity != Vector3::ZERO || enemyNode->getPosition().y > 100) 
		{
			velocity = velocity + acc * 10 * elapsedTime;
			enemyNode->translate(velocity);
			if(enemyNode->getPosition().y < 100)
				enemyNode->setPosition(enemyNode->getPosition().x, 100,enemyNode->getPosition().z);
		}
		// Stop when hit ground
		else 
		{
			velocity.y = 0;
		}
	}
	else {
		deadCount--;
		if(deadCount == 0) {
			enemyNode->detachObject( entity );
			toRemove = true;
		}
	}
}
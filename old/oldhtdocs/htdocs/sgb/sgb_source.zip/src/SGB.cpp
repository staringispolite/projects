/*
-----------------------------------------------------------------------------
This source file is part of OGRE
(Object-oriented Graphics Rendering Engine)
For the latest info, see http://www.ogre3d.org/

Copyright (c) 2000-2005 The OGRE Team
Also see acknowledgements in Readme.html

You may use this sample code for anything you like, it is not covered by the
LGPL like the rest of the engine.
-----------------------------------------------------------------------------
*/


#include "SGB.h"
#include <fstream>
#include <sstream>
#include "Sound.h"

using namespace std;

//-------------------------------------------------------------------------------------
SGBApp::SGBApp(void)
{
	//PlaySound("mario.wav", NULL, SND_ASYNC);
	camLocal = Vector3::ZERO;
	currCharacter = -1;
	currLevel = -1;
	firsttime = true;
	keyDown = KC_YEN;
	levels = NULL;
	levelNames = NULL;
	mainMenu = false;
	numLevels = 0;
	pause = false;
	backgroundSound = new Sound("..//..//Audio//theme song beat box.wav");
}
//-------------------------------------------------------------------------------------
SGBApp::~SGBApp(void)
{
} 

Vector3 SGBApp::cameraMovement() {
	Real dist;
	//zone at which the camera does not move
	Real dead_zone_radius = 50;
	//"knob" varible change this to tweak how much the camera follows
	Real m = 15; 
	//distance between player and camera on the Z plane (2D)
	if(world->getLevel()->getPlayer()->getNode()->getPosition().z >= world->getLevel()->getRightBound()) 
	{
		dist = world->getLevel()->getRightBound() - mCamera->getPosition().z;
		dead_zone_radius = 0;
		m = 30;
	}
	else if (world->getLevel()->getPlayer()->getNode()->getPosition().z <= world->getLevel()->getLeftBound())
		return Vector3::ZERO;
	else
		dist = world->getLevel()->getPlayer()->getNode()->getPosition().z - mCamera->getPosition().z;
	//height change that the camera needs to make
	Real height = world->getLevel()->getPlayer()->getNode()->getPosition().y  + world->getLevel()->getPlayer()->getHeight() - (mCamera->getPosition().y - 50);
	if(dist > dead_zone_radius)
		return Vector3(0,height,dist/m);
	if(dist < -dead_zone_radius)
		return Vector3(0,height,dist/m); 
	return Vector3(0,height,0);;
}

//-------------------------------------------------------------------------------------
void SGBApp::createScene(void)
{
	loadCharacters();
	loadLevels();
	overlayMgr = OverlayManager::getSingletonPtr();
	world = new World(mSceneMgr);
	world->load(levels[0],characters[0]);
	//Entity* ogreHead = mSceneMgr->createEntity( "Ninja", "ninja.mesh" );

	//SceneNode* headNode = mSceneMgr->getRootSceneNode()->createChildSceneNode("NinjaNode");
	//headNode->attachObject(ogreHead);
	// Set ambient light
	mSceneMgr->setAmbientLight(ColourValue(0.5, 0.5, 0.5));

	// Create a light
	Light* l = mSceneMgr->createLight("MainLight");
	l->setPosition(world->getLevel()->getPlayer()->getNode()->getPosition() + Vector3(-100,200,200));
	l->setCastShadows(true);

	camLocal = world->getLevel()->getPlayer()->getNode()->getPosition() + Vector3(-400,500,3000);
	
}

bool SGBApp::frameStarted(const FrameEvent& evt)
{
	if(firsttime)
	{
		//Sound * backgroundSound = new Sound("Mario.wav");
		backgroundSound->Loop();
		firsttime = false;
	}

	if (!pause)
	{
		world->getLevel()->advance(evt.timeSinceLastFrame);
		world->checkCollision();
	}

	if(mWindow->isClosed())
		return false;

	if (!mInputTypeSwitchingOn)
	{
		mInputDevice->capture();
	}
	


	if ( !mUseBufferedInputMouse || !mUseBufferedInputKeys)
	{
		// one of the input modes is immediate, so setup what is needed for immediate mouse/key movement
		if (mTimeUntilNextToggle >= 0)
			mTimeUntilNextToggle -= evt.timeSinceLastFrame;

		// If this is the first frame, pick a speed
		if (evt.timeSinceLastFrame == 0)
		{
			mMoveScale = 1;
			mRotScale = 0.1;
		}
		// Otherwise scale movement units by time passed since last frame
		else
		{
			// Move about 100 units per second,
			mMoveScale = mMoveSpeed * evt.timeSinceLastFrame;
			// Take about 10 seconds for full rotation
			mRotScale = mRotateSpeed * evt.timeSinceLastFrame;
			
		}
		mRotX = 0;
		mRotY = 0;
		mTranslateVector = Vector3::ZERO;
		charTranslateVector = Vector3::ZERO;
	}

	if (mUseBufferedInputKeys)
	{
		// no need to do any processing here, it is handled by event processor and
		// you get the results as KeyEvents
	}
	else
	{
		if (processUnbufferedKeyInput(evt) == false)
		{
			return false;
		}
	}
	if (mUseBufferedInputMouse)
	{
		// no need to do any processing here, it is handled by event processor and
		// you get the results as MouseEvents
	}
	else
	{
		if (processUnbufferedMouseInput(evt) == false)
		{
			return false;
		}
	}

	if ( !mUseBufferedInputMouse || !mUseBufferedInputKeys)
	{
		// one of the input modes is immediate, so update the movement vector
		
		moveCamera();

	}
	

	return true;
}

void SGBApp::loadCharacters()
{
	try
	{
		ifstream fin ("..\\..\\Docs\\Characters.txt");
		fin >> numCharacters;
		characters = new String[numCharacters]();
		characterNames = new String[numCharacters]();
		for (int i = 0; i < numCharacters; i++)
		{
			fin >> characterNames[i];
			fin >> characters[i];
		}
		fin.close();
	}
	catch (...)
	{
		exit(200);
	}
}

void SGBApp::loadLevels()
{
	try
	{
		ifstream fin ("..\\..\\Docs\\Levels.txt");
		fin >> numLevels;
		levels = new String[numLevels]();
		levelNames = new String[numLevels]();
		for (int i = 0; i < numLevels; i++)
		{
			fin >> levels[i];
			levels[i] = "..\\..\\Docs\\" + levels[i];
			ifstream nameIn (levels[i].c_str());

			char read[256];
			nameIn.getline(read,256);
			levelNames[i] = read + 11;
			nameIn.close();
		}
		fin.close();
	}
	catch (...)
	{
		exit(100);
	}
}

void SGBApp::menuChangeCharacter()
{
	currCharacter++;
	if (currCharacter >= numCharacters) currCharacter = 0;
	overlayMgr->getOverlayElement("SGB/MainPanel/Character")->setCaption("[C] Character - " + characterNames[currCharacter]);
}

void SGBApp::menuChangeLevel()
{
	currLevel++;
	if (currLevel >= numLevels) currLevel = 0;
	overlayMgr->getOverlayElement("SGB/MainPanel/Level")->setCaption("[L] Level - " + levelNames[currLevel]);
}

//Move Camera Function is here
void SGBApp::moveCamera()
{

	Light *l = mSceneMgr->getLight("MainLight");
	l->setPosition(world->getLevel()->getPlayer()->getNode()->getPosition() + Vector3(-100,200,0));

	// Make all the changes to the camera
	// Note that YAW direction is around a fixed axis (freelook style) rather than a natural YAW (e.g. airplane)
	if(world->getLevel()->getPlayer()->isPlayerDead()) {
		mCamera->yaw(mRotX);
		mCamera->pitch(mRotY);
	}
	//mCamera->moveRelative(mTranslateVector);
	if(!(world->getLevel()->getPlayer()->isPlayerDead() )) {
		camLocal += cameraMovement();
		mCamera->setPosition(camLocal);
		if(!(world->getLevel()->getPlayer()->getNode()->getPosition().z < world->getLevel()->getLeftBound())){
			if(!(world->getLevel()->getPlayer()->getNode()->getPosition().z >= world->getLevel()->getRightBound())) {
				mCamera->lookAt(world->getLevel()->getPlayer()->getNode()->getPosition() + Vector3(0,100,0));
				lookAtVector = world->getLevel()->getPlayer()->getNode()->getPosition() + Vector3(0,100,0);
			}
			else {
				mCamera->lookAt(lookAtVector);
			}
		}
	}
}

bool SGBApp::processUnbufferedKeyInput(const FrameEvent& evt)
{
	if (keyDown != KC_YEN)
	{
		if(mInputDevice->isKeyDown(keyDown))
		{
			return true;
		}
		keyDown = KC_YEN;
	}

	if(mInputDevice->isKeyDown( KC_ESCAPE) )
	{
		togglePause();
		keyDown = KC_ESCAPE;
	}

	if (mInputDevice->isKeyDown(KC_M))
	{
		toggleMainMenu();
		keyDown = KC_M;
	}

	if (mainMenu)
	{
		// Change Character Command
		if (mInputDevice->isKeyDown(KC_C))
		{
			menuChangeCharacter();
			keyDown = KC_C;
		}

		// Change Level Command
		if (mInputDevice->isKeyDown(KC_L))
		{
			menuChangeLevel();
			keyDown = KC_L;
		}

		// Load Level Command
		if (mInputDevice->isKeyDown(KC_RETURN))
		{
			if (currLevel >= 0 && currCharacter >=0)
			{
				toggleMainMenu();
				overlayMgr->getOverlayElement("SGB/MainPanel/Character")->setCaption("[C] Character");
				overlayMgr->getOverlayElement("SGB/MainPanel/Level")->setCaption("[L] Level");
				world->load(levels[currLevel],characters[currCharacter]);
				world->reset();
				currCharacter = -1;
				currLevel = -1;
			}
		}

		return true;
	}

	// Do not process certain commands while the game is paused
	if (pause)
	{
		// Reset Command
		if (mInputDevice->isKeyDown(KC_C))
		{
			togglePause();
		}

		// Quit Command
		if (mInputDevice->isKeyDown(KC_Q))
		{
			return false;
		}

		// Reset Command
		if (mInputDevice->isKeyDown(KC_R))
		{
			world->reset();
			togglePause();
		}

		return true;
	}
	if(world->getLevel()->getPlayer()->hasWon()) {
		world->getLevel()->getPlayer()->moveLeft();
		world->getLevel()->getPlayer()->startWalking(-mMoveScale*30);

	}
	else if (mInputDevice->isKeyDown(KC_LEFT))
	{
		world->getLevel()->getPlayer()->moveLeft();

		if(mInputDevice->isKeyDown(KC_LSHIFT) || mInputDevice->isKeyDown(KC_RSHIFT)) 
		{
			// Start running
			world->getLevel()->getPlayer()->startRunning(-mMoveScale*60);
		} 
		else 
		{
			// Start walking
			world->getLevel()->getPlayer()->startWalking(-mMoveScale*30);
		}		
	}

	if (mInputDevice->isKeyDown(KC_RIGHT))
	{
		world->getLevel()->getPlayer()->moveRight();
		
		if(mInputDevice->isKeyDown(KC_LSHIFT) || mInputDevice->isKeyDown(KC_RSHIFT)) 
		{
			 // Start running
			world->getLevel()->getPlayer()->startRunning(mMoveScale*60);
		} 
		else 
		{
			// Start walking
			world->getLevel()->getPlayer()->startWalking(mMoveScale*30);
		}
	}

	if((!mInputDevice->isKeyDown(KC_LEFT)) && (!mInputDevice->isKeyDown(KC_RIGHT))) 
	{
		//Stop walking/running
		if((!world->getLevel()->getPlayer()->hasWon() || world->getLevel()->getPlayer()->negVelocity())) 
		{
			world->getLevel()->getPlayer()->moveStop();
			if (!world->getLevel()->getPlayer()->isJumping()) 
			{
				world->getLevel()->getPlayer()->stopAnimation();
			}
		}
	}

	// Jump Command
	if(mInputDevice->isKeyDown(KC_SPACE))
	{
		world->getLevel()->getPlayer()->jump();
	}

	if (mInputDevice->isKeyDown(KC_A))
	{
		// Move camera left
		mTranslateVector.x = -mMoveScale;
	}

	if (mInputDevice->isKeyDown(KC_D))
	{
		// Move camera RIGHT
		mTranslateVector.x = mMoveScale;
	}

	/* Move camera forward by keypress. */
	if (mInputDevice->isKeyDown(KC_UP) || mInputDevice->isKeyDown(KC_W) )
	{
		mTranslateVector.z = -mMoveScale;
	}

	/* Move camera backward by keypress. */
	if (mInputDevice->isKeyDown(KC_DOWN) || mInputDevice->isKeyDown(KC_S) )
	{
		mTranslateVector.z = mMoveScale;
	}

	if (mInputDevice->isKeyDown(KC_SYSRQ) && mTimeUntilNextToggle <= 0)
	{
		char tmp[20];
		sprintf(tmp, "screenshot_%d.png", ++mNumScreenShots);
		mWindow->writeContentsToFile(tmp);
		mTimeUntilNextToggle = 0.5;
		mWindow->setDebugText(String("Wrote ") + tmp);
	}

	// Return true to continue rendering
	return true;
}

void SGBApp::toggleMainMenu()
{
	pause = !pause;
	mainMenu = !mainMenu;
	Overlay* mainMenu = overlayMgr->getByName("SGB/Main");
	if (mainMenu->isVisible()) mainMenu->hide(); 
	else mainMenu->show();
}

void SGBApp::togglePause()
{
	pause = !pause;
	Overlay* pauseMenu = overlayMgr->getByName("SGB/Pause");
	if (pauseMenu->isVisible()) pauseMenu->hide();
	else pauseMenu->show();
}

void SGBApp::updateStats(void)
{
	static String currFps = "Super Graphic Brothers";
	static String time = "Time: ";
	static String bestFps = "Score: ";
	static String worstFps = "Current Ability: None";
	static String tris = "Level: Opening";
	std::ostringstream score;
	score << world->getLevel()->score;

	// update stats when necessary
	try {
		OverlayElement* guiAvg = OverlayManager::getSingleton().getOverlayElement("Core/AverageFps");
		OverlayElement* guiCurr = OverlayManager::getSingleton().getOverlayElement("Core/CurrFps");
		OverlayElement* guiBest = OverlayManager::getSingleton().getOverlayElement("Core/BestFps");
		OverlayElement* guiWorst = OverlayManager::getSingleton().getOverlayElement("Core/WorstFps");

		const RenderTarget::FrameStats& stats = mWindow->getStatistics();

		guiAvg->setCaption(time + StringConverter::toString(world->getLevel()->getTimeLeft()));
		guiCurr->setCaption(currFps);
		guiBest->setCaption(worstFps);
		guiWorst->setCaption(bestFps + score.str());

		OverlayElement* guiTris = OverlayManager::getSingleton().getOverlayElement("Core/NumTris");
		guiTris->setCaption(tris);

		OverlayElement* guiDbg = OverlayManager::getSingleton().getOverlayElement("Core/DebugText");
		guiDbg->setCaption(mWindow->getDebugText());
	}
	catch(...)
	{
		// ignore
	}
}

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"
#endif

#ifdef __cplusplus
	extern "C" {
#endif

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
		INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT )
#else
		int main(int argc, char *argv[])
#endif
		{
			// Create application object
			SGBApp app;

			SET_TERM_HANDLER;

			try {
				app.go();
			} catch( Ogre::Exception& e ) {
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
				MessageBox( NULL, e.getFullDescription().c_str(), "An exception has occured!", MB_OK | MB_ICONERROR | MB_TASKMODAL);
#else
				std::cerr << "An exception has occured: " <<
					e.getFullDescription().c_str() << std::endl;
#endif
			}

			return 0;
		}

#ifdef __cplusplus
	}
#endif

#include "Aplus.h"

Aplus::Aplus(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot) {
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"a_plus.mesh" );
	itemNode = mSceneMgr->createSceneNode(name);
  itemNode->translate(initialPos);
  itemNode->rotate(initialRot);
  this->initialPos = initialPos;
  itemRadius = 15;
  acc = Vector3(0,0,0);
	velocity = Vector3(0,0,0);
}

void Aplus::load() {
	itemNode->attachObject( entity );
  // No animation states for Aplus yet
  isAnimated = false;
}

void Aplus::advance(Ogre::Real elapsedTime) {
  if (itemNode == NULL) {
    return;
  }
  if (isAnimated) {
		mAnimationState->addTime( elapsedTime );
  }
  if (moving) {
    velocity = velocity + acc;
	if(itemNode->getPosition().y <= 110) {
		velocity.y = 0;
		velocity.z = 0;
		itemNode->setPosition(itemNode->getPosition().x,110,itemNode->getPosition().z);
	}
	else
		velocity.z = 2;
    itemNode->translate(velocity);
    if (velocity.y >= (initialPos.y + 20)) {
      velocity = Vector3(0, 0, 0);
    }
  }
}

int Aplus::checkCollision(Player *player) {
	if (itemNode == NULL) {
    return 0;
  }
	if(!moving)
		return 0;
	Vector3 pPos = player->getNode()->getWorldPosition();
  Vector3 pPos2 = player->getNode()->getWorldPosition();
  Vector3 pPos3 = player->getNode()->getWorldPosition();
  Vector3 pPos4 = player->getNode()->getWorldPosition();
  Vector3 pPos5 = player->getNode()->getWorldPosition();
	Vector3 iPos = itemNode->getWorldPosition();
  pPos2.y += 20; 
  pPos3.y += 40;
  pPos4.y += 60;

  pPos.y += player->getHeight();
	if (iPos.positionEquals(pPos5,itemRadius) ||
		iPos.positionEquals(pPos,itemRadius) ||
      iPos.positionEquals(pPos2,itemRadius)  ||
      iPos.positionEquals(pPos3,itemRadius)  ||
      iPos.positionEquals(pPos4,itemRadius))
  	{
    // Collision response is the same regardless of direction.
    hit();
    player->growBig();
		if (pPos.y - 2 > iPos.y)
		{  // Collision above.
			return 2;
    } else {
		  return 1;
    }
	}
	else
	{
		return 0;
	}

}

void Aplus::initMotion() {
  velocity = Vector3(0, 18, 0);
  acc = Vector3(0, -1, 0);
}
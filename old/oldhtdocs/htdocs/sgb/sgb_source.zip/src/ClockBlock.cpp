#include "ClockBlock.h"
#include "Clock.h"
#include "Sound.h"

ClockBlock::ClockBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn, Sound *coinSoundIn):
    QuestionBlock(mgrIn, name, initialPos, initialRot, contentMeshName, numContentsIn) {

  itemContent = new Item*[numContentsIn];
  for (int i = 0; i < numContentsIn; i++) {
    Ogre::String thisItemName(name);
    char buffer[33];
    thisItemName.append("content");
    thisItemName.append(itoa(i, buffer, 10));
    itemContent[i] = new Clock(mgrIn, thisItemName, initialPos, initialRot);
	coinSound = coinSoundIn;
  }
}

	ClockBlock::~ClockBlock()
	{
		delete coinSound;
	}

void ClockBlock::load() {
  //Load parent (block)
  QuestionBlock::load();
  //Load items
  for (int i = 0; i < numContents; i++) {
    if (itemContent[i] != NULL) {
      itemContent[i]->load();
      itemContent[i]->setVisible(false);
      mSceneMgr->getSceneNode("Level")->addChild(itemContent[i]->getNode());
    }
  }
}

void ClockBlock::emitItem() {
  if (numItemsEmitted < numContents) {
    if (itemContent[numItemsEmitted] != NULL) {
      contentNode = itemContent[numItemsEmitted]->getNode();
      //contentNode->setPosition(initialPos.x, initialPos.y + 20, initialPos.z);
      itemContent[numItemsEmitted]->setVisible(true);
      itemContent[numItemsEmitted]->setMoving(true);
	  // Trigger sound
	  //Sound * mySound = new Sound("Coin.wav");
	  coinSound->Play();
      numItemsEmitted++;
    }
    //Test emptiness
    if (numItemsEmitted >= numContents) {
      makeEmpty();
    }
  }
}



#include "Middleground.h"


Middleground::Middleground(SceneManager* mgrIn)
{
	mSceneMgr = mgrIn;
	node = mSceneMgr->getSceneNode("Environment")->createChildSceneNode("Middleground");
	entity = mSceneMgr->createEntity("Hills", "hills.mesh" );

}

Middleground::~Middleground()
{

}

void Middleground::load()
{
	node->attachObject( entity );

	node->translate(Vector3(300,100,100));
	//node->rotate(Quaternion(Degree(90), Vector3::UNIT_Y));
}

SceneNode* Middleground::getNode()
{
	return node;
}
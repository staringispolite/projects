#include "Item.h"
#include "Sound.h"

Item::Item()
{
  visible = true;
  moving = false;
}

Item::~Item()
{

}

int Item::checkCollision(Player *player)
{
  if (itemNode == NULL) {
    return 0;
  }
  Vector3 pPos = player->getNode()->getWorldPosition();
	Vector3 ePos = itemNode->getWorldPosition();
	if (ePos.positionEquals(pPos,itemRadius))
	{
		if (pPos.y - 2 > ePos.y)
		{
			return 2;
		}
		return 1;
	}
	else
	{
		return 0;
	}
}

SceneNode* Item::getNode()
{
	return itemNode;
}

void Item::hit()
{
	//itemNode->detachObject( entity );
  mSceneMgr->destroySceneNode(itemNode->getName());
  itemNode = NULL;
}

void Item::setVisible(bool vis) {
  entity->setVisible(vis);
  visible = vis;
}

void Item::setMoving(bool moving) {
  if ((this->moving == false)  && (moving == true)){
    initMotion();
  }
  this->moving = moving;
}
#include "MtnDewBlock.h"
#include "MtnDew.h"

MtnDewBlock::MtnDewBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn):
    QuestionBlock(mgrIn, name, initialPos, initialRot, contentMeshName, numContentsIn) {

  itemContent = new Item*[numContentsIn];
  for (int i = 0; i < numContentsIn; i++) {
    Ogre::String thisItemName(name);
    char buffer[33];
    thisItemName.append("content");
    thisItemName.append(itoa(i, buffer, 10));
    itemContent[i] = new MtnDew(mgrIn, thisItemName, initialPos, initialRot);
  }
}

void MtnDewBlock::load() {
  //Load parent (block)
  QuestionBlock::load();
  //Load items
  for (int i = 0; i < numContents; i++) {
    if (itemContent[i] != NULL) {
      itemContent[i]->load();
      itemContent[i]->setVisible(false);
      mSceneMgr->getSceneNode("Level")->addChild(itemContent[i]->getNode());
    }
  }
}

void MtnDewBlock::emitItem() {
  if (numItemsEmitted < numContents) {
    if (itemContent[numItemsEmitted] != NULL) {
      contentNode = itemContent[numItemsEmitted]->getNode();
      //contentNode->setPosition(initialPos.x, initialPos.y + 20, initialPos.z);
      itemContent[numItemsEmitted]->setVisible(true);
      itemContent[numItemsEmitted]->setMoving(true);
      numItemsEmitted++;
    }
    //Test emptiness
    if (numItemsEmitted >= numContents) {
      makeEmpty();
    }
  }
}
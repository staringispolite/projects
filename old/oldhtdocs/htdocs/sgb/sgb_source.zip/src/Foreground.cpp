


#include "Foreground.h"


Foreground::Foreground(SceneManager* mgrIn)
{
	mSceneMgr = mgrIn;
	node = mSceneMgr->getSceneNode("Environment")->createChildSceneNode("Foreground");
	entity = mSceneMgr->createEntity("Ground", "ground.mesh" );

}

Foreground::~Foreground()
{

}

void Foreground::load()
{
	node->attachObject( entity );
	node->translate(Vector3(100,100,100));
	//node->rotate(Quaternion(Degree(90), Vector3::UNIT_Y));

	//mSceneMgr->setWorldGeometry( "terrain.cfg" );
	//mSceneMgr->setSkyBox( true, "Examples/SpaceSkyBox" );
}

SceneNode* Foreground::getNode()
{
	return node;
}
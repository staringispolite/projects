#include "Block.h"

Block::Block(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,Sound *blockBreakSoundIn) {
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"block_brick.mesh" );
	itemNode = mSceneMgr->createSceneNode(name);
  bumpedAlready = false;

  this->initialPos = initialPos;
	itemNode->translate(initialPos);
	itemNode->rotate(initialRot);
	itemRadius = 15;

  acc = Vector3(0,0,0);
	velocity = Vector3(0,0,0);

	blockBreakSound = blockBreakSoundIn;

}

Block::~Block()
{
	delete blockBreakSound;
}

void Block::load() {
	itemNode->attachObject( entity );
  // No animation states for bricks yet
  isAnimated = false;
}

void Block::advance(Ogre::Real elapsedTime) {
  if (itemNode == NULL) {
    return;
  }
  if (isAnimated) {
		mAnimationState->addTime( elapsedTime );
  }
  velocity = velocity + acc;
  itemNode->translate(velocity);
  if (itemNode->getWorldPosition().y < initialPos.y) {
    // The block has gotten back to its original position after the "bump" from small char.
    // Stop it and reset.
    acc = Vector3(0, 0, 0);
    velocity = Vector3(0, 0, 0);
    itemNode->translate(initialPos - itemNode->getWorldPosition());
    bumpedAlready = false;
  }
}

int Block::checkCollision(Player *player) 
{
	if (itemNode == NULL) 
	{
		return 0;
	}
	
	Vector3 pPos = player->getNode()->getWorldPosition();
	Vector3 pPos2 = player->getNode()->getWorldPosition();
	Vector3 pPos3 = player->getNode()->getWorldPosition();
	Vector3 pPos4 = player->getNode()->getWorldPosition();
	Vector3 pPos5 = player->getNode()->getWorldPosition();
	Vector3 iPos = itemNode->getWorldPosition();
	pPos2.y += 20;
	pPos3.y += 40;
	pPos4.y += 60;
	pPos.y += player->getHeight();
	if (iPos.positionEquals(pPos,itemRadius) ||
		iPos.positionEquals(pPos2,itemRadius)||
		iPos.positionEquals(pPos3,itemRadius)||
		iPos.positionEquals(pPos4,itemRadius)||
		iPos.positionEquals(pPos5,itemRadius))
	{
		bool checkBounce = true;

		if ((pPos.y - player->getHeight()) > iPos.y-5)
		{
			//Collision above
			player->setStopFlagBottom(itemNode->getPosition().y + 2 * itemRadius);
			checkBounce = false;
		}
		else
		{
			//Collision on the side
			if ((iPos.z - pPos.z < 22) && (iPos.z - pPos.z > 0))
			{
				player->setStopFlagRight();
			}
			if ((pPos.z - iPos.z < 22) && (pPos.z - iPos.z > 0))
			{
				player->setStopFlagLeft();
			}
		}
 
		if (checkBounce && (pPos.y < iPos.y)) 
		{
			//Collision from below
			if (!player->isPlayerBig() && !player->negVelocity()) 
			{  // player is small
				if (!bumpedAlready)
				{// Bump the block up
					velocity.y = 10;
					acc.y = -2;
					bumpedAlready = true;
					player->setVelocity(0);
				}
			}
			else if(!player->negVelocity()) 
			{    // player is big
				blockBreakSound->Play();
				hit();
				player->setVelocity(0);
			}
			//resolve collision
			Vector3 newPlayerPos = player->getNode()->getPosition();
			newPlayerPos.y = initialPos.y - (player->getHeight() + itemRadius);
			player->getNode()->setPosition(newPlayerPos);
			return 1;
		}
	} 
	return 0;
}
#include "Pipe.h"

Pipe::Pipe(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot, int scale) {
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"pipe_bottom.mesh" );
	entityTop = mSceneMgr->createEntity(name+"top","pipe_top.mesh" );
	itemNode = mSceneMgr->createSceneNode(name);
	itemNodeTop = mSceneMgr->createSceneNode(name+"top");
  bumpedAlready = false;

  this->initialPos = initialPos;
	itemNode->translate(initialPos);
	itemNode->rotate(initialRot);
	itemNode->scale(1,1+scale,1);
	initialPos.y+=0;
	itemNodeTop->translate(initialPos);
	itemNodeTop->translate(0,20*scale,0);
	itemNodeTop->rotate(initialRot);
	itemRadius = 20 + scale*10;

  acc = Vector3(0,0,0);
	velocity = Vector3(0,0,0);
}

void Pipe::load() {
	itemNode->attachObject( entity );
	itemNodeTop->attachObject(entityTop);
	mSceneMgr->getSceneNode("Level")->addChild(itemNodeTop);
  // No animation states for bricks yet
  isAnimated = false;
}

void Pipe::advance(Ogre::Real elapsedTime) {
	if (itemNode == NULL) {
		return;
	}
	if (isAnimated) {
		mAnimationState->addTime( elapsedTime );
	}
	velocity = velocity + acc;
	itemNode->translate(velocity);
	if (itemNode->getWorldPosition().y < initialPos.y) {
		// The block has gotten back to its original position after the "bump" from small char.
		// Stop it and reset.
		acc = Vector3(0, 0, 0);
		velocity = Vector3(0, 0, 0);
		itemNode->translate(initialPos - itemNode->getWorldPosition());
		bumpedAlready = false;
	}
}

int Pipe::checkCollision(Player *player) {
	if (itemNode == NULL) {
		return 0;
	}

	Vector3 pPos = player->getNode()->getWorldPosition();
	Vector3 pPos2 = player->getNode()->getWorldPosition();
	Vector3 pPos3 = player->getNode()->getWorldPosition();
	Vector3 pPos4 = player->getNode()->getWorldPosition();
	Vector3 pPos5 = player->getNode()->getWorldPosition();
	Vector3 iPos = itemNode->getWorldPosition();
	pPos2.y += 20;
	pPos3.y += 40;
	pPos4.y += 60;
	pPos.y += player->getHeight();
	if (iPos.positionEquals(pPos,itemRadius) ||
		iPos.positionEquals(pPos2,itemRadius)||
		iPos.positionEquals(pPos3,itemRadius)||
		iPos.positionEquals(pPos4,itemRadius)||
		iPos.positionEquals(pPos5,itemRadius))
	{
		bool checkBounce = true;

		if ((pPos.y - player->getHeight()) > iPos.y-5) {
			//Collision above
			player->setStopFlagBottom(itemNode->getPosition().y + itemRadius + 10);
			checkBounce = false;
		}
		else {
			//Collision on the side
			if ((iPos.z - pPos.z < 22) && (iPos.z - pPos.z > 0)) {
				player->setStopFlagRight();
			}
			if ((pPos.z - iPos.z < 22) && (pPos.z - iPos.z > 0)) {
				player->setStopFlagLeft();
			}
		}

		if (checkBounce && (pPos.y < iPos.y)) {
			//Collision from below
			if (!player->isPlayerBig()) {  // player is small
				if (!bumpedAlready) {// Bump the block up
					velocity.y = 10;
					acc.y = -2;
					bumpedAlready = true;
					player->setVelocity(0);
				}
			} else {    // player is big
				hit();
				player->setVelocity(0);
			}
			//resolve collision
			Vector3 newPlayerPos = player->getNode()->getPosition();
			newPlayerPos.y = initialPos.y - (player->getHeight() + itemRadius);
			player->getNode()->setPosition(newPlayerPos);
			return 1;
		}
	} else {
		return 0;
	}
}
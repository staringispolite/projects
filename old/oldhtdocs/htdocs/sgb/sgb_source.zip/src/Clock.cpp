#include "BaseApplication.h"
#include "Clock.h"

Clock::Clock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot) {
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"clock.mesh" );
	itemNode = mSceneMgr->createSceneNode(name);
  itemNode->translate(initialPos);
  itemNode->rotate(initialRot);
  itemRadius = 10;
  rotateSpeed = 2;
  acc = Vector3(0,0,0);
	velocity = Vector3(0,0,0);
}

void Clock::load() {
	itemNode->attachObject( entity );
  // No animation states for clocks yet
  isAnimated = false;
}

void Clock::advance(Ogre::Real elapsedTime) {
  if (itemNode == NULL) {
    return;
  }
  if (isAnimated) {
		mAnimationState->addTime( elapsedTime );
  }
  if (moving) {
    velocity = velocity + acc;
    itemNode->translate(velocity);
    itemNode->rotate(Vector3(0,1,0), Ogre::Radian(rotateSpeed));
    if (velocity.y <= -7) {
      // disappear halfway through fall.
      // todo(jhoward): animate this with rotation as well
      
      hit();
    }
  }
}

int Clock::checkCollision(Player *player) {
	if (itemNode == NULL) {
    return 0;
  }
	Vector3 pPos = player->getNode()->getWorldPosition();
  Vector3 pPos2 = player->getNode()->getWorldPosition();
  Vector3 pPos3 = player->getNode()->getWorldPosition();
  Vector3 pPos4 = player->getNode()->getWorldPosition();
  Vector3 pPos5 = player->getNode()->getWorldPosition();
	Vector3 iPos = itemNode->getWorldPosition();
  pPos2.y += 20; 
  pPos3.y += 40;
  pPos4.y += 60;
  pPos.y += player->getHeight();
	if (iPos.positionEquals(pPos5,itemRadius) ||
		  iPos.positionEquals(pPos,itemRadius) ||
      iPos.positionEquals(pPos2,itemRadius)  ||
      iPos.positionEquals(pPos3,itemRadius)  ||
      iPos.positionEquals(pPos4,itemRadius))
	{
    setMoving(true);
    initMotion();
		if (pPos.y - 2 > iPos.y)
		{  //Collision above
			return 2;
    } else {
      // Collision below
		  return 1;
    }
	}
	else
	{
		return 0;
	}
}

void Clock::initMotion() {
  rotateSpeed = 10;
  velocity = Vector3(0, 18, 0);
  acc = Vector3(0, -2, 0);
}



#include "World.h"


World::World(SceneManager* mgrIn)
{
	mSceneMgr = mgrIn;
	score = 0;
	reseting = false;
	startSound = new Sound("Audio\\you got sgb.wav");
	jumpingSound = new Sound("Audio\\jump.wav");
	getBigSound = new Sound("Audio\\getBig.wav");
	getSmallSound = new Sound("Audio\\getSmall.wav");
	dieSound1 = new Sound("Audio\\die music 1.wav");
	dieSound2 = new Sound("Audio\\die music 2.wav");
	dieSound3 = new Sound("Audio\\die music 3.wav");
	dewSound = new Sound("Audio\\mtn dew power.wav");
	killSound1 = new Sound("Audio\\goomba_kill_1.wav");
	killSound2 = new Sound("Audio\\goomba_kill_2.wav");
	killSound3 = new Sound("Audio\\goomba_kill_3.wav");
	killSound4 = new Sound("Audio\\goomba_kill_4.wav");
	blockBreakSound = new Sound("Audio\\block break.wav");
	coinSound = new Sound("Audio\\extension.wav");
	hitSound = new Sound("Audio\\block bump.wav");

}

World::~World()
{

}

void World::load(String levelFile, String playerMesh)
{
	mSceneMgr->clearScene();
	delete level;
	level = new Level(mSceneMgr,levelFile, playerMesh, startSound, jumpingSound, getBigSound, getSmallSound, dieSound1, dieSound2, dieSound3, dewSound, killSound1, killSound2, killSound3, killSound4, blockBreakSound,coinSound,hitSound);
	level->load();
}

void World::reset()
{	

		String levelFile = level->getLevelFile();
		String playerMesh = level->getPlayerMesh();

		delete level;
		mSceneMgr->clearScene();

		mSceneMgr->setAmbientLight(ColourValue(0.5, 0.5, 0.5));

	level = new Level(mSceneMgr,levelFile,playerMesh, startSound, jumpingSound, getBigSound, getSmallSound, dieSound1, dieSound2, dieSound3, dewSound, killSound1, killSound2, killSound3, killSound4, blockBreakSound,coinSound,hitSound);

		level->load();

 		// Create a light
		Light* l = mSceneMgr->createLight("MainLight");
		l->setPosition(level->getPlayer()->getNode()->getPosition() + Vector3(-100,200,0));
		l->setCastShadows(true);
}

void World::checkCollision()
{
	level->checkCollision();
}

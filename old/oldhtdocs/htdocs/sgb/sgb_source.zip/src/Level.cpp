#include "Level.h"
#include <sstream>
#include <fstream>
#include <iostream>
#include "string.h"

using namespace std;

Level::Level(SceneManager* mgrIn, String lf, String playerName, Sound *startSoundIn, 
			 Sound *jumpingSoundIn, Sound *getBigSoundIn, Sound *getSmallSoundIn, 
			 Sound *dieSound1In, Sound *dieSound2In, Sound *dieSound3In, 
			 Sound *dewSoundIn, Sound *killSound1In, Sound *killSound2In, 
			 Sound *killSound3In, Sound *killSound4In, Sound *blockBreakSoundIn,
			 Sound *coinSoundIn, Sound *hitSoundIn)
{


	startSound = startSoundIn;
	jumpingSound = jumpingSoundIn;
	getBigSound = getBigSoundIn;
	getSmallSound = getSmallSoundIn;
	dieSound1 = dieSound1In;
	dieSound2 = dieSound2In;
	dieSound3 = dieSound3In;
	dewSound = dewSoundIn;
	killSound1 = killSound1In;
	killSound2 = killSound2In;
	killSound3 = killSound3In;
	killSound4 = killSound4In;
	blockBreakSound = blockBreakSoundIn;
	coinSound = coinSoundIn;
	hitSound = hitSoundIn;


	startSound->Play();

	mSceneMgr = mgrIn;
	score = 0;
	//timeLimit = 150;
	totalElapsedTime = 0;
	
	levelFile = lf;
	levelNode = mSceneMgr->getRootSceneNode()->createChildSceneNode("Level");
	environment = new Environment(mgrIn);

	numObjects = 1;
	object = new Object*[numObjects];
	object[0] = new Object(mgrIn);
	   

	player = new Player(mgrIn,playerName, jumpingSound, getBigSound, getSmallSound, dieSound1, dieSound2,dieSound3,dewSound);


	loadFromFile(mSceneMgr);

 
	

	leftBound = 0;
	rightBound = 4000;


/*
	// Create enemies and objects ----------------------------------------------------------------------------
	numEnemies = 3;
	enemy = new Enemy*[numEnemies];

	enemy[0] = new EnemyGoomba(mgrIn,"Goomba1",Vector3(100,200,040),Quaternion(Degree(-90), Vector3::UNIT_Y));
	enemy[1] = new EnemyGoomba(mgrIn,"Goomba2",Vector3(100,250,300),Quaternion(Degree(-90), Vector3::UNIT_Y));
	enemy[2] = new EnemyFlyingGoomba(mgrIn,"FlyingGoomba1",Vector3(100,250,300),Quaternion(Degree(-90), Vector3::UNIT_Y));


  numItems = 9;
  item = new Item*[numItems];
    item[0] = new Block(mgrIn, "BrickBlock1", Vector3(100, 210, 300 + (20*0)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[1] = new Block(mgrIn, "BrickBlock2", Vector3(100, 210, 300 + (20*1)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[2] = new Block(mgrIn, "BrickBlock3", Vector3(100, 210, 300 + (20*2)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[3] = new ClockBlock(mgrIn, "CoinBlock1", Vector3(100, 210, 300 + (20*3)), Quaternion(Degree(-90), Vector3::UNIT_Y),
                                "clock.mesh", 10);
    item[4] = new Block(mgrIn, "BrickBlock4", Vector3(100, 210, 300 + (20*4)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[5] = new Block(mgrIn, "BrickBlock5", Vector3(100, 210, 300 + (20*5)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[6] = new Block(mgrIn, "BrickBlock6", Vector3(100, 210, 300 + (20*6)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[7] = new Aplus(mgrIn, "Aplus1", Vector3(100, 200, 130), Quaternion(Degree(-90), Vector3::UNIT_Y));
    item[8] = new MtnDew(mgrIn, "MtnDew1", Vector3(100, 200, 580), Quaternion(Degree(-90), Vector3::UNIT_Y));

*/

  /*for (int i = 0; i < numItems; i++) {
    if (i == 4) { // a row of 7 blocks, the middle one is a coin block.
      item[i] = new CoinBlock(mgrIn, "CoinBlock" + i, Vector3(100, 200, 300 + (20*i)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    } else {
      item[i] = new Block(mgrIn, Ogre::String("BrickBlock" + i), Vector3(100, 200, 300 + (20*i)), Quaternion(Degree(-90), Vector3::UNIT_Y));
    }
  } //For some reason having the name "CoinBlock" + i, and "BrickBlock" + i, give an error "already an entity 'Block'.
    //This makes no sense, but I'll try unrolling the loop.
  */

	// Add components to Level SceneNode as children --------------------------------------------------------
	//levelNode->addChild(environment->getNode()); 
	for (int i = 0; i < numEnemies; i++) if (enemy[i] != NULL) levelNode->addChild(enemy[i]->getNode());
	for (int i = 0; i < numObjects; i++) if (object[i] != NULL) levelNode->addChild(object[i]->getNode());
	for (int i = 0; i < numItems; i++) if (item[i] != NULL) levelNode->addChild(item[i]->getNode());
}

Level::~Level()
{
	for (int i = 0; i < numEnemies; i++)
		if (enemy[i] != NULL) delete enemy[i];
	delete[] enemy;

	for (int i = 0; i < numObjects; i++)
		if (object[i] != NULL) delete object[i];
	delete[] object;

	for (int i = 0; i < numItems; i++)
		if (item[i] != NULL) delete item[i];
	delete[] item;
}

void Level::advance(Ogre::Real elapsedTime)
{

	checkWin();

  totalElapsedTime += elapsedTime;
  if ((!player->isPlayerDead()) && (totalElapsedTime > timeLimit)) {
    //end level
    player->kill();
  }
  player->advance(elapsedTime);
	for (int i = 0; i < numEnemies; i++) 
		if (enemy[i] != NULL) {
			enemy[i]->advance(elapsedTime);
			if(enemy[i]->toDelete()) {
					delete enemy[i];
					enemy[i] = NULL;
			}
		}
	//for (int i = 0; i < numObjects; i++) object[i]->advance(elapsedTime);
 	for (int i = 0; i < numItems; i++) if (item[i] != NULL) item[i]->advance(elapsedTime);

}

void Level::load()
{
	environment->load();
	player->load();
	for (int i = 0; i < numEnemies; i++) enemy[i]->load();
	for (int i = 0; i < numObjects; i++) object[i]->load();
	for (int i = 0; i < numItems; i++) item[i]->load();
}

SceneNode* Level::getNode()
{
	return levelNode;
}

void Level::checkCollision()
{
  // Check player collisions with enemies.
  for (int i = 0; i < numEnemies; i++)
	{
		if (enemy[i] != NULL) 
		{
			int returned;
			if (returned = enemy[i]->checkCollision(player))
			{
				if (returned == 2)
				{
					player->setVelocity(20.0);
					score++;
				}
				else
					player->hurt();
			}
		}
	}
  // Check collisions with items.
  for (int i = 0; i < numItems; i++)
	{
		if (item[i] != NULL) 
		{
			int returned;
			if (returned = item[i]->checkCollision(player))
			{

      }
    }
  }
  //enemy[i].checkCollision(width,height,point)
	//player->setVel(20);
}

String Level::getLevelFile()
{
	return levelFile;
}

String Level::getPlayerMesh()
{
	return player->getPlayerMesh();
}

void Level::loadFromFile(SceneManager* mgrIn)
{
	fstream fin (levelFile.c_str());
	char title[256];

	//cout << fin.is_open() << endl;

	//Read level name
	fin.getline(title,256);
	//This next line will give a pointer to the text after the = sign
	//strchr(title, '=')+1 

	//Read gravity in
	fin.getline(title,256);

	//Read Time Limit
	fin.getline(title,256);
	timeLimit = atol(strchr(title, '=')+1);
	
	//Read how many planes
	fin.getline(title,256);

	int numplanes = atol(strchr(title, '=')+1);

	//cout << "Planes: " << numplanes << endl;

	//Read foreground
	fin.getline(title,256);

	//Read filename
	fin.getline(title,256);

	//Read scroll speed
	fin.getline(title,256);

	//loop for amount of planes

	for(int c = 0; c < numplanes; c++)
	{
		//Read plane
		fin.getline(title,256);

		//Read filename
		fin.getline(title,256);

		//Read scroll speed
		fin.getline(title,256);

		//Read offset from foreground
		fin.getline(title,256);
	}

	//Read how many enemies
	fin.getline(title,256);

	numEnemies = atol(strchr(title, '=')+1);


	enemy = new Enemy*[numEnemies];

	//loop for amount of enemies

	for(int c = 0; c < numEnemies; c++)
	{
		//Read enemy
		fin.getline(title,256);

		//Read enemy type
		fin.getline(title,256);
		char enemyType[256];
		strcpy(enemyType, strchr(title, '=')+1);

		//cout << "%%" << enemyType << "%%" << endl;

		//Read enemy location
		fin.getline(title,256);
		int x = atol(strchr(title, '=')+1);
		int y = atol(strchr(title, ',')+1);

		//cout << "Location: " << x << "," << y << endl;

		//Read enemy ai
		fin.getline(title,256);

		strcpy(title, enemyType);
		char temp[5];
		ltoa(c+1, temp , 30);
		strcat(title,temp);

		if(!strcmp(enemyType, "goomba"))
			enemy[c] = new EnemyGoomba(mgrIn,title,Vector3(100,x,y),Quaternion(Degree(-90), Vector3::UNIT_Y), killSound1, killSound2, killSound3, killSound4);

		if(!strcmp(enemyType, "flyinggoomba"))
			enemy[c] = new EnemyFlyingGoomba(mgrIn,title,Vector3(100,x,y),Quaternion(Degree(-90), Vector3::UNIT_Y), killSound1, killSound2, killSound3, killSound4);


	}

	//Read how many items
	fin.getline(title,256);

	numItems = atol(strchr(title, '=')+1);

	item = new Item*[numItems];

	//loop for amount of items

	for(int c = 0; c < numItems; c++)
	{
		//Read item
		fin.getline(title,256);

		//Read item type
		fin.getline(title,256);
		char itemType[256];
		strcpy(itemType, strchr(title, '=')+1);

		//Read item location
		fin.getline(title,256);
		int x = atol(strchr(title, '=')+1);
		int y = atol(strchr(title, ',')+1);
	
		//Read item quantity
		fin.getline(title,256);
		int quantity = atol(strchr(title, '=')+1);

		strcpy(title, itemType);
		char temp[5];
		ltoa(c+1, temp , 30);
		strcat(title,temp);


			if(!strcmp(itemType, "BrickBlock"))
				item[c] = new Block(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y), blockBreakSound);

			if(!strcmp(itemType, "Pipe"))
				item[c] = new Pipe(mgrIn, title, Vector3(90, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y), quantity);

			if(!strcmp(itemType, "ClockBlock"))
				item[c] = new ClockBlock(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y), "clock.mesh", 1, coinSound);

			if(!strcmp(itemType, "AplusBlock"))
				item[c] = new AplusBlock(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y), "aplus.mesh", 1, hitSound);

			if(!strcmp(itemType, "MtnDewBlock"))
				item[c] = new MtnDewBlock(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y), "mtn_dew.mesh", 1);

			if(!strcmp(itemType, "Aplus"))
				item[c] = new Aplus(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y));

			if(!strcmp(itemType, "MountainDew"))
				item[c] = new MtnDew(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y));

			if(!strcmp(itemType, "Clock"))
				item[c] = new Clock(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y));
					
			if(!strcmp(itemType, "Testudo"))
			{
				endLevel = new Testudo(mgrIn, title, Vector3(100, x, y), Quaternion(Degree(-90), Vector3::UNIT_Y));
				item[c] = endLevel;
			}
	}

}

void Level::checkWin() {
	if(endLevel->isDown()) {
		wonLevel = true;
		player->winAnimation();
	}
}
#include "MtnDew.h"

MtnDew::MtnDew(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot) {
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"mtn_dew.mesh" );
	itemNode = mSceneMgr->createSceneNode(name);
  itemNode->translate(initialPos);
  itemNode->rotate(initialRot);
  this->initialPos = initialPos;
  itemRadius = 15;
  acc = Vector3(0,0,0);
	velocity = Vector3(0,0,0);
}

void MtnDew::load() {
	itemNode->attachObject( entity );
  // No animation states for MtnDew yet
  isAnimated = false;
}

void MtnDew::advance(Ogre::Real elapsedTime) {
  if (itemNode == NULL) {
    return;
  }

  if (isAnimated) {
		mAnimationState->addTime( elapsedTime );
  }
  if (moving) {
    velocity = velocity + acc;
    itemNode->translate(velocity);
    Vector3 pos = itemNode->getWorldPosition();
    if (pos.y <= 110) {
      pos.y = 110;
      itemNode->setPosition(pos);
      velocity.y *= -.8;
    }
  }
}

int MtnDew::checkCollision(Player *player) {
	if (itemNode == NULL) {
    return 0;
  }


 if(!moving)
		return 0;
	Vector3 pPos = player->getNode()->getWorldPosition();
  Vector3 pPos2 = player->getNode()->getWorldPosition();
  Vector3 pPos3 = player->getNode()->getWorldPosition();
  Vector3 pPos4 = player->getNode()->getWorldPosition();
  Vector3 pPos5 = player->getNode()->getWorldPosition();
	Vector3 iPos = itemNode->getWorldPosition();
  pPos2.y += 20; 
  pPos3.y += 40;
  pPos4.y += 60;

  pPos.y += player->getHeight();
	if (iPos.positionEquals(pPos5,itemRadius) ||
		iPos.positionEquals(pPos,itemRadius) ||
      iPos.positionEquals(pPos2,itemRadius)  ||
      iPos.positionEquals(pPos3,itemRadius)  ||
      iPos.positionEquals(pPos4,itemRadius))
  	{
		player->doTheDew();
    hit();
    player->setInvincible();
		if (pPos.y - 2 > iPos.y)
		{  //Collision above
			return 2;
    } else {
		  return 1;
    }
	}
	else
	{
		return 0;
	}
}

void MtnDew::initMotion() {
  velocity = Vector3(0, 20, 1);
  acc = Vector3(0, -2, 0);
}
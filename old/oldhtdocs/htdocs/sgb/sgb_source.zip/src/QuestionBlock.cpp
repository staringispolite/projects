#include "QuestionBlock.h"

QuestionBlock::QuestionBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn) {
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"block_coin.mesh" );
	itemNode = mSceneMgr->createSceneNode(name);
  numContents = numContentsIn;
  numItemsEmitted = 0;
  bumpedAlready = false;

  this->initialPos = initialPos;
	itemNode->translate(initialPos);
	itemNode->rotate(initialRot);
	itemRadius = 15;

  acc = Vector3(0,0,0);
	velocity = Vector3(0,0,0);
}

void QuestionBlock::load() {
	itemNode->attachObject( entity );
  //No animation states for bricks yet
  isAnimated = false;
}

void QuestionBlock::advance(Ogre::Real elapsedTime) {
  if (itemNode == NULL) {
    return;
  }
  if (isAnimated) {
		mAnimationState->addTime( elapsedTime );
  }
  velocity = velocity + acc;
  itemNode->translate(velocity);
  if (itemNode->getWorldPosition().y < initialPos.y) {
    // The block has gotten back to its original position after the "bump" from small char.
    // Stop it and reset.
    acc = Vector3(0, 0, 0);
    velocity = Vector3(0, 0, 0);
    itemNode->translate(initialPos - itemNode->getWorldPosition());
    bumpedAlready = false;
  }

  for (int i = 0;  i < numContents; i++) {
    if (itemContent != NULL) {
      Item* thisItem = itemContent[i];
      if (thisItem != NULL) {
        thisItem->advance(elapsedTime);
      }
    }
  }
}

int QuestionBlock::checkCollision(Player *player) {
	if (itemNode == NULL) {
    return 0;
  }
for (int i = 0;  i < numContents; i++) {
	if (itemContent != NULL) {
      Item* thisItem = itemContent[i];
      if (thisItem != NULL) {
		  thisItem->checkCollision(player);
      }
    }
  }


  Vector3 pPos = player->getNode()->getWorldPosition();
  Vector3 pPos2 = player->getNode()->getWorldPosition();
  Vector3 pPos3 = player->getNode()->getWorldPosition();
  Vector3 pPos4 = player->getNode()->getWorldPosition();
  Vector3 pPos5 = player->getNode()->getWorldPosition();
	Vector3 iPos = itemNode->getWorldPosition();
  pPos2.y += 20;
  pPos3.y += 40;
  pPos4.y += 60;
  pPos.y += player->getHeight();
	if (iPos.positionEquals(pPos,itemRadius) ||
      iPos.positionEquals(pPos2,itemRadius)||
      iPos.positionEquals(pPos3,itemRadius)||
      iPos.positionEquals(pPos4,itemRadius)||
      iPos.positionEquals(pPos5,itemRadius))
	{
    bool checkBounce = true;
    
	if ((pPos.y - player->getHeight()) > iPos.y-5) {
      //Collision above
		player->setStopFlagBottom(itemNode->getPosition().y + 2 * itemRadius);
      checkBounce = false;
    }
	else {
		//Collision on the side
		if ((iPos.z - pPos.z < 22) && (iPos.z - pPos.z > 0)) {
		  player->setStopFlagRight();
		}
		if ((pPos.z - iPos.z < 22) && (pPos.z - iPos.z > 0)) {
		  player->setStopFlagLeft();
		}
	}
	if (checkBounce && (pPos.y < iPos.y)) {
      // Bump the block up
      if (!bumpedAlready && (numItemsEmitted < numContents)) {  // '?' Boxes expire once used up
        velocity.y = 10;
        acc.y = -2;
        emitItem();
        bumpedAlready = true;
        player->setVelocity(0);
      }
	  else {
		  player->setVelocity(0);
	  }
      //resolve collision
      Vector3 newPlayerPos = player->getNode()->getPosition();
      newPlayerPos.y = initialPos.y - (player->getHeight() + itemRadius);
      player->getNode()->setPosition(newPlayerPos);
  	  return 1;
    }
	}
	else
	{
		return 0;
	}
}

//Changes the block to an empty state and changes the graphic
void QuestionBlock::makeEmpty() {
  itemNode->detachAllObjects();
  Ogre::String newName = entity->getName();
  mSceneMgr->destroyEntity(entity);
  entity = mSceneMgr->createEntity(newName, "block_q_empty.mesh");
  itemNode->attachObject(entity);
}
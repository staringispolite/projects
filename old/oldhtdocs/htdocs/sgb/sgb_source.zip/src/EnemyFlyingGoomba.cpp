#include "EnemyFlyingGoomba.h"

EnemyFlyingGoomba::EnemyFlyingGoomba(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot, Sound *killSound1In, Sound *killSound2In, Sound *killSound3In, Sound *killSound4In)
{
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"goomba_air.mesh");
	enemyNode = mSceneMgr->createSceneNode(name);

	enemyNode->translate(initialPos);
	enemyNode->rotate(initialRot);
	enemyRadius = 15;
	territoryCenter = initialPos.z;

	velocity = Vector3(0,0,1);
			killSound[0] = killSound1In;
	killSound[1] = killSound2In;
	killSound[2] = killSound3In;
	killSound[3] = killSound4In;
}

void EnemyFlyingGoomba::load()
{
	enemyNode->attachObject( entity );
}

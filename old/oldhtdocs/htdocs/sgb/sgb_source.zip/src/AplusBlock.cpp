#include "AplusBlock.h"
#include "Aplus.h"
#include "Sound.h"

AplusBlock::AplusBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn,
			 Sound *hitSoundIn):
    QuestionBlock(mgrIn, name, initialPos, initialRot, contentMeshName, numContentsIn) 
{

	itemContent = new Item*[numContentsIn];
	for (int i = 0; i < numContentsIn; i++) 
	{
		Ogre::String thisItemName(name);
		char buffer[33];
		thisItemName.append("content");
		thisItemName.append(itoa(i, buffer, 10));
		itemContent[i] = new Aplus(mgrIn, thisItemName, initialPos, initialRot);
	}
	hitSound = hitSoundIn;
}

AplusBlock::~AplusBlock()
{
	delete hitSound;
	// TODO Need to properly delete...
	/*for (int i = 0; i < numContentsIn; i++)
	{
		delete itemContent[i];
	}*/
	delete itemContent;
}

void AplusBlock::load() 
{
  //Load parent (block)
  QuestionBlock::load();
  //Load items
  for (int i = 0; i < numContents; i++) 
  {
    if (itemContent[i] != NULL) 
	{
      itemContent[i]->load();
      itemContent[i]->setVisible(false);
      mSceneMgr->getSceneNode("Level")->addChild(itemContent[i]->getNode());
    }
  }
}

void AplusBlock::emitItem() {
  if (numItemsEmitted < numContents) {
    if (itemContent[numItemsEmitted] != NULL) {
      contentNode = itemContent[numItemsEmitted]->getNode();
      //contentNode->setPosition(initialPos.x, initialPos.y + 20, initialPos.z);
      itemContent[numItemsEmitted]->setVisible(true);
      itemContent[numItemsEmitted]->setMoving(true);
	  hitSound->Play();
      numItemsEmitted++;
    }
    //Test emptiness
    if (numItemsEmitted >= numContents) {
      makeEmpty();
    }
  }
}
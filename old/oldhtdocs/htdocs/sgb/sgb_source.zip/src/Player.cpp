#include "Player.h"
#include "Sound.h"

const int SIZE_VAR = 2;
Player::Player(SceneManager* mgrIn, String pMesh, Sound *jumpingSoundIn, Sound *getBigSoundIn, Sound *getSmallSoundIn, Sound *dieSound1In, Sound *dieSound2In, Sound *dieSound3In, Sound *dewSoundIn) : velocity(Vector3(0.0, 0.0, 0.0)), jumpVelocity(20.0), acc(Vector3(0.0,-5,0.0)), ground(100), jumping(false), isBig(false), isFacingRight(true), turn(0), safeTimer(75), isSafe(true), isDead(false), isDewPower(false), currentColor(RED), stopFlagRight(false), stopFlagLeft(false), stopFlagBottom(false)
{
	mSceneMgr = mgrIn;
	playerMesh = pMesh;
	entity = mSceneMgr->createEntity("MainChar",playerMesh + "_walk.mesh");
	node = mSceneMgr->getRootSceneNode()->createChildSceneNode("Player");
	nodeRotate = node->createChildSceneNode("PlayerRotate");

	jumpingSound = jumpingSoundIn;
	getBigSound = getBigSoundIn;
	getSmallSound = getSmallSoundIn;
	dieSound = new Sound*[3];

	dieSound[0] = dieSound1In;
	dieSound[1] = dieSound2In;
	dieSound[2] = dieSound3In;
	dewSound = dewSoundIn;
	//endSound = new Sound("..\\..\\Audio\\end of level.wav");
}

Player::~Player()
{
	jumpingSound->KillALData();
	delete jumpingSound;
	//delete jumpingSound;
	//delete getBigSound;
	//delete dieSound;
}

void Player::load()
{
	nodeRotate->attachObject( entity );
	node->translate(Vector3(100,100,100));

  isBig = true; // So that shrink will succeed
	shrinkSmall();

  //Initially no animation
  isAnimated = false;
  totalElapsedTime = 0;
  
  //entity->setMaterialName("dew_yellow");
  entity->setMaterialName("SGB_" + playerMesh);

wonLevel = false;

  //node->rotate(Quaternion(Degree(90), Vector3::UNIT_Y));
}

void Player::reset()
{
	velocity = Vector3(0.0, 0.0, 0.0);
	jumpVelocity = 25.0;
	acc = Vector3(0.0,-5,0.0);
	jumping = false;
	turnRight();
	turn = 0;
	safeTimer = 75;
	isSafe = true;
	isDead = false;
	if (isBig)
		shrinkSmall();
	node->translate(Vector3(100,100,100) - node->getPosition());

	isAnimated = false;
	totalElapsedTime = 0;
}

SceneNode* Player::getNode()
{
	return node;
}

String Player::getPlayerMesh()
{
	return playerMesh;
}

void Player::advance(Real elapsedTime)
{

	if(wonLevel) {
		moveLeft();
		startWalking(60);
	}
		
	if(isDead) // Play die sequence
		killAnimation(elapsedTime);
	else {

		if(isDewPower) {
			if(mDewCount % 5 == 0)
				colorToggle();

			mDewCount--;
			if (mDewCount == 0)
				dewOver();
		}
		if(stopFlagRight==true) {
			if(moveVector.z >= 0)
				moveVector.z = 0;
			stopFlagRight = false;
		}
		else if(stopFlagLeft == true) {
			if(moveVector.z <= 0)
				moveVector.z = 0;
			stopFlagLeft = false;
		}
		if(wonLevel)
			moveVector.z = 60;
		node->translate( node->getOrientation() * moveVector * elapsedTime );
		if(safeTimer > 0){ // temp "safe mode" after spawn or hit by enemy
			if(safeTimer % 5 == 0)
				visableToggle();
			safeTimer--;
			if(safeTimer == 0) {
				isSafe = false;
				if(!isVisible)
					visableToggle();
			}
    }

    // Invincible mode.
    if (invincible) {
      if (invincibleTimer > 0) {
        invincibleTimer--;
      } else {
        invincible = false;
      }
    }

    // Advance animation.
    if (isAnimated) { 
      mAnimationState->addTime(elapsedTime);
      totalElapsedTime += elapsedTime; // Track for animation switches.
    }

    // Turning is separate from other motion.
		if(turn > 0) {
			turn--;
			nodeRotate->rotate(Quaternion(Degree(36), Vector3::UNIT_Y));
		}

    // Physics / ground collision.
    if(velocity.y > 0 || node->getPosition().y > ground) {
			if(stopFlagBottom == true) {
				if (node->getPosition().y < platform) {

				
					node->setPosition(node->getPosition().x,platform-20,node->getPosition().z);
					velocity.y = 0;
					stopFlagBottom = false;
					if(!wonLevel)
						endJumping();
					jumping = false;
				}
			}
			else {
				velocity = velocity + acc * 10* elapsedTime;
				node->translate(velocity);
			}
			
			if(node->getPosition().y < ground)
				node->setPosition(node->getPosition().x, ground,node->getPosition().z);
			
			
	}
	else {
			velocity.y = 0;
			if(!wonLevel)
				endJumping();
			jumping = false;
		}
	}
	//stop when hit ground
}
void Player::jump() {
	if(jumping == false) {
		setVelocity(jumpVelocity);
    // Trigger sound
		jumpingSound->Play();
    // Trigger animation
		startJumping();
	}
}

void Player::setVelocity(double v)
{
	velocity.y = v;
}

void Player::setStopFlagRight()
{
	stopFlagRight = true;
}

void Player::setStopFlagLeft()
{
	stopFlagLeft = true;
}

void Player::setStopFlagBottom(Real platformIn)
{
	stopFlagBottom = true;
	platform = platformIn;
}

void Player::growBig() {
  if (isBig == false) { //don't grow infinitely
    node->scale(1.25,1.25,1.25);
	  jumpVelocity *= 1.25;
    height = 90;
    isBig = true;
	  //Sound * mySound = new Sound("Getbig.wav");
	  getBigSound->Play();
  }
}

void Player::shrinkSmall() {
  if (isBig == true) { //don't shrink infinitely
    isSafe = true;
    safeTimer = 20;
    node->scale(.8,.8,.8);
	  jumpVelocity *= .8;
    height = 70;
	getSmallSound->Play();
    isBig = false;
  }
}

void Player::setInvincible() {
  invincible = true;
  dewSound->Play();
  invincibleTimer = 200;
}

void Player::turnLeft() {
	if(turn == 0) {
	isFacingRight = false;
	turn = 5;
	}
}

void Player::turnRight() {
	if(turn == 0) {
	isFacingRight = true;
	turn = 5;
	}
	
}

void Player::visableToggle() {
	if(isVisible){
		isVisible = false;
		entity->setVisible(false);
	}
	else 
	{
		isVisible = true;
		entity->setVisible(true);
	}
}

void Player::test() {
	/*
		 Light *light = mSceneMgr->createLight( "above" );
		 light->setType( Light::LT_SPOTLIGHT );
		 Vector3 above = Vector3(-100, height, 0);
		 light->setPosition(node->getPosition() + above);
		 light->setDirection(1,0,0);
		 light->setSpotlightRange(Radian(0.0), Radian(0.785), 1);
		 light->setDiffuseColour( ColourValue::Red );
		 light->setSpecularColour( ColourValue::Red );
	*/
		//node->getMaternode->getMaterial()->setSelfIllumination(1,0,0);
}

void Player::killAnimation(Real elapsedTime)
{
	nodeRotate->rotate(Quaternion(Degree(35), Vector3::UNIT_Y));
	velocity = velocity + acc * 10* elapsedTime;
	node->translate(velocity);
}

void Player::hurt() {
  if (!invincible && !isSafe) {
    if (isBig) {
      shrinkSmall();
    } else {
      kill();
    }
  }
}

void Player::kill() {
  isDead = true;
  dieSound[(rand()%3)]->Play();
  node->translate(Vector3(20,0,0));
  setVelocity(5);
}

void Player::winAnimation()
{
	//endSound->Play();
	wonLevel = true;
	//turn = 5;
}
void Player::doTheDew()
{
	setInvincible();
	mDewCount  = 200;
	isDewPower = true;
	colorToggle();
}

void Player::dewOver()
{
	isDewPower = false;
	entity->setMaterialName("SGB_" + playerMesh);
}
void Player::colorToggle()
{
	if(currentColor == GREEN){
		currentColor = YELLOW;
		entity->setMaterialName(playerMesh + "_dew_yellow");
	}
	else if(currentColor == YELLOW) {
		currentColor = RED;
		entity->setMaterialName(playerMesh + "_dew_red");
	}
	else {
		currentColor = GREEN;
		entity->setMaterialName(playerMesh + "_dew_green");
	}

}


//Animation Control
void Player::startWalking(float moveSpeed) {
		moveVector.z = moveSpeed;

  if ((isAnimated == false) && (!jumping)) {
    mAnimationState = entity->getAnimationState( playerMesh + "_walk" );
    mAnimationState->setLoop( true );
    mAnimationState->setEnabled( true );
    mAnimationState->addTime(totalElapsedTime);
	  isAnimated = true;
  }
}

void Player::startRunning(float moveSpeed) {
		moveVector.z = moveSpeed/2;

  startWalking(moveSpeed);
/*  if ((isAnimated == false) && (!jumping)){
    mAnimationState = entity->getAnimationState( "mount_run" );
    mAnimationState->setLoop( true );
    mAnimationState->setEnabled( true );
    mAnimationState->addTime(totalElapsedTime);
	  isAnimated = true;
  }
  */
}
 
void Player::startJumping() {
  if (jumping == false) {
    mAnimationState = entity->getAnimationState( playerMesh + "_jump_start" );
    mAnimationState->setLoop( false );
    mAnimationState->setEnabled( true );
    totalElapsedTime = 0;
    mAnimationState->setTimePosition(totalElapsedTime);
	  isAnimated = true;
    jumping = true;
	stopFlagBottom = false;
  }
}

void Player::endJumping() {
  if (jumping == true) {
    //reset to beginning of walk cycle - jump looks different
    //startWalking();
    //stop playback
    stopAnimation();
    jumping = false;
  }
    /*  mAnimationState = entity->getAnimationState( playerMesh + "_jump_end" );
    mAnimationState->setLoop( false );
    mAnimationState->setEnabled( true );
    totalElapsedTime = 0;
    mAnimationState->setTimePosition(totalElapsedTime);
	  isAnimated = true;
    jumping = false;
  }
  */
}

void Player::stopAnimation(){
	moveStop(); 
	//Check if mAnimationState has been initialized
  if (mAnimationState != NULL) {
    //if (mAnimationState->getTimePosition() > (mAnimationState->getLength()/2)) {
    //  mAnimationState->setLoop(false); // Finish current step if halfway throguh animation
    //} else {
      mAnimationState->setTimePosition(0); // Stop immediately
      mAnimationState->setEnabled(false);
      isAnimated = false;
    //}
  }
  totalElapsedTime = 0;
}

void Player::moveRight() {
	if(!isFacingRight) {
			turnRight();
	}
}

void Player::moveLeft() {
		if(isFacingRight) {
			turnLeft();
		}
}

void Player::moveStop() {
	moveVector.z = 0.0;
}

bool Player::negVelocity() {
	if(velocity.y < 0)
		return true;
	else
		return false;
} 
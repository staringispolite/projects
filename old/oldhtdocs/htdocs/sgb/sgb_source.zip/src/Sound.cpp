#include "Sound.h"

#include <conio.h>
#include <stdlib.h>
#include <stdio.h>			//For some reason, stdio.h were not included, so I added it(TheCell)
#include <time.h>
//See Explanation 1

#include <al.h>
#include <alc.h>
//#include <al/alut.c>		Since I have not found alut.c anywhere, I suppose we use alut.h
#include <alut.h>		//Added by TheCell
//See explanation 2

Sound::Sound(ALchar * FileName)
{
	for(int i = 0; i < 3; i++)
	{
		SourcePos[i] =  0.0;
		SourceVel[i] =  0.0;
		ListenerPos[i] =  0.0;
		ListenerVel[i] =  0.0;
	}

	ListenerOri[0] = 0.0;
	ListenerOri[1] = 0.0;
	ListenerOri[2] = -1.0;
	ListenerOri[3] = 0.0;
	ListenerOri[4] = 1.0;
	ListenerOri[5] = 0.0;

	this->FileName = FileName;

	// Initialize OpenAL and clear the error bit.

	alutInit(NULL, 0);
	alGetError();

	// Load the wav data.

	if(LoadALData() == AL_FALSE)
	{
		printf("Error loading data.");
		//return 0;
	}

	SetListenerValues();

}

Sound::~Sound()
{
	KillALData();
}


/*
* ALboolean LoadALData()
*
*	This function will load our sample data from the disk using the Alut
*	utility and send the data into OpenAL as a buffer. A source is then
*	also created to play that buffer.
*/
ALboolean Sound::LoadALData()
{
	// Variables to load into.

	ALenum format;
	ALsizei size;
	ALvoid* data;
	ALsizei freq;
	ALboolean loop;

	// Load wav data into a buffer.

	alGenBuffers(1, &Buffer);

	if(alGetError() != AL_NO_ERROR)
		return AL_FALSE;

	alutLoadWAVFile(FileName, &format, &data, &size, &freq, &loop);
	alBufferData(Buffer, format, data, size, freq);
	alutUnloadWAV(format, data, size, freq);

	//Buffer = alutCreateBufferFromFile(FileName);

	// Bind the buffer with the source.

	alGenSources(1, &Source);

	if(alGetError() != AL_NO_ERROR)
		return AL_FALSE;

	alSourcei (Source, AL_BUFFER,   Buffer   );
	alSourcef (Source, AL_PITCH,    1.0      );
	alSourcef (Source, AL_GAIN,     1.0      );
	alSourcefv(Source, AL_POSITION, SourcePos);
	alSourcefv(Source, AL_VELOCITY, SourceVel);
	alSourcei (Source, AL_LOOPING,  loop     );

	// Do another error check and return.

	if(alGetError() == AL_NO_ERROR)
		return AL_TRUE;

	return AL_FALSE;
}



/*
* void SetListenerValues()
*
*	We already defined certain values for the Listener, but we need
*	to tell OpenAL to use that data. This function does just that.
*/
void Sound::SetListenerValues()
{
	alListenerfv(AL_POSITION,    ListenerPos);
	alListenerfv(AL_VELOCITY,    ListenerVel);
	alListenerfv(AL_ORIENTATION, ListenerOri);
}



/*
* void KillALData()
*
*	We have allocated memory for our buffers and sources which needs
*	to be returned to the system. This function frees that memory.
*/
void Sound::KillALData()
{
	alDeleteBuffers(1, &Buffer);
	alDeleteSources(1, &Source);
	alutExit();
}

int Sound::Play()
{
	alSourcePlay(Source);

	return 0;
}

int Sound::Loop()
{
	alSourcei (Source, AL_LOOPING,  AL_TRUE     );

	alSourcePlay(Source);

	return 0;
}
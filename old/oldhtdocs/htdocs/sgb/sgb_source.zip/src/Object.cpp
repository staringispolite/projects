
#include "Object.h"


Object::Object(SceneManager* mgrIn)
{
	mSceneMgr = mgrIn;
	node = new SceneNode(mSceneMgr, "Objects");
}

Object::~Object()
{

}

void Object::load()
{

}

SceneNode* Object::getNode()
{
	return node;
}
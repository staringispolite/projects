


#include "Environment.h"


Environment::Environment(SceneManager* mgrIn)
{
	mSceneMgr = mgrIn;
	node = mSceneMgr->getSceneNode("Level")->createChildSceneNode("Environment");

	foreground = new Foreground(mgrIn);
	middleground = new Middleground(mgrIn);
	background = new Background(mgrIn);


}

Environment::~Environment()
{

}

void Environment::load()
{
   foreground->load();
   middleground->load();
   background->load();
}

SceneNode* Environment::getNode()
{
	return node;
}
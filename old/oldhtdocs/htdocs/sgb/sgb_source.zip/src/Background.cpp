


#include "Background.h"


Background::Background(SceneManager* mgrIn)
{
	mSceneMgr = mgrIn;
	node = mSceneMgr->getSceneNode("Environment")->createChildSceneNode("Background");
	entity = mSceneMgr->createEntity("Sky", "sky.mesh" );

}

Background::~Background()
{

}

void Background::load()
{
	node->attachObject( entity );
	node->scale(1,1,2);
	node->translate(Vector3(500,100,100));
	//node->rotate(Quaternion(Degree(90), Vector3::UNIT_Y));
}

SceneNode* Background::getNode()
{
	return node;
}
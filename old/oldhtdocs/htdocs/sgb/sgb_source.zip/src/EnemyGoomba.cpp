#include "EnemyGoomba.h"

EnemyGoomba::EnemyGoomba(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot, Sound *killSound1In, Sound *killSound2In, Sound *killSound3In, Sound *killSound4In)
{
	isAnimated = false;
	mSceneMgr = mgrIn;
	entity = mSceneMgr->createEntity(name,"goomba_black.mesh" );
	//entity = mSceneMgr->createEntity(name,"robot.mesh");
	enemyNode = mSceneMgr->createSceneNode(name);

	enemyNode->translate(initialPos);
	enemyNode->rotate(initialRot);
	enemyRadius = 20;

	territoryCenter = initialPos.z;

	velocity = Vector3(0,0,1);
		killSound[0] = killSound1In;
	killSound[1] = killSound2In;
	killSound[2] = killSound3In;
	killSound[3] = killSound4In;

}

void EnemyGoomba::load()
{
	enemyNode->attachObject( entity );
	 //mAnimationState = entity->getAnimationState( "Idle" );
	 mAnimationState = entity->getAnimationState( "goomba_walk" );
        mAnimationState->setLoop( true );
        mAnimationState->setEnabled( true );
		isAnimated = true;
	//enemyNode->translate(Vector3(100,200,100));
	//enemyNode->rotate(Quaternion(Degree(-90), Vector3::UNIT_Y));
		
}
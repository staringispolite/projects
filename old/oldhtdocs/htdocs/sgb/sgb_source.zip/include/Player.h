#ifndef __Player_h_
#define __Player_h_

#include "BaseApplication.h"
#include "Sound.h"

class Player
{
private:
	//Variables for Scene Management
	Entity * entity;
	SceneManager* mSceneMgr;
	SceneNode* node;
	SceneNode* nodeRotate;
	String playerMesh;

	//Animation Variables
	AnimationState* mAnimationState;
	bool isAnimated;
	Ogre::Real totalElapsedTime;

	//Misc Player Variables
	int height;
	bool isDead;
	bool wonLevel;
	bool stopFlagRight;
	bool stopFlagLeft;
	bool stopFlagBottom;
	Vector3 moveVector;
	
	
	//Item / Power-up Variables
	bool isBig;
	bool invincible;
	int invincibleTimer;

	//Variables for jumping
	bool jumping;
	Real jumpVelocity;
	Vector3 velocity;
	Vector3 acc;
	Real ground;
	Real platform;

	//Variables for turning left and right
	int turn;
	bool isFacingRight;

	//Invincibility initial spawn
	bool isSafe;
	int safeTimer;

	//Enum and Variables for Mountain Dew Power
	enum mDewColor {GREEN = 0, YELLOW, RED};
	enum mDewColor currentColor;
	bool isDewPower;
	int mDewCount;

	//Invicibility for initial spawn
	bool isVisible;


	//Sounds
	Sound * jumpingSound;
	Sound * getBigSound;
	Sound * getSmallSound;
	Sound ** dieSound;
	Sound * dewSound;
	//Sound * endSound;

public:

  
    Player(SceneManager* mgrIn, String pMesh, Sound *jumpingSoundIn, Sound *getBigSoundIn, Sound *getSmallSoundIn, Sound *dieSound1In, Sound *dieSound2In, Sound *dieSound3In, Sound *dewSoundIn);

	~Player(void);
	
	void advance(Real elapsedTime);
	String getPlayerMesh();
	void load();
	void reset();
	void jump();
	void setVelocity(double v);
	void setStopFlagRight();
	void setStopFlagLeft();
	void setStopFlagBottom(Real platformIn);
	void winAnimation();

	// Setting special properties
	void growBig();
	void shrinkSmall();
	void setInvincible();

	//Motion control
	void turnLeft();
	void turnRight();
	void visableToggle();
	void test();

	//getters
	SceneNode* getNode();		
	int getHeight() { return height; }
	bool isJumping() { return jumping; }
	bool isPlayerBig() { return isBig; }
	bool isPlayerFacingRight()  { return isFacingRight; }
	bool isPlayerDead() { return isDead; }
	bool isInvincible() { return invincible; }
	bool hasWon() { return wonLevel; }
	bool negVelocity();

	//kill player & kill animation 
	void killAnimation(Real elapsedTime);
	void hurt();
	void kill();

	//Dew
	void doTheDew();
	void dewOver();
	void colorToggle();

	// Animation control
	void moveRight();
	void moveLeft();
	void moveStop();
	void startWalking(float moveSpeed);
	void startRunning(float moveSpeed);
	void startJumping();
	void endJumping();
	void stopAnimation();
};


#endif // #ifndef __World_h_
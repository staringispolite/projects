#ifndef __QuestionBlock_h_
#define __QuestionBlock_h_

#include "BaseApplication.h"
#include "Item.h"

class QuestionBlock : public Item {
protected:
    // Need to reset after a bump
    Vector3 initialPos;
    bool bumpedAlready;

    // Contains a number of items as contents
    SceneNode* contentNode;
  	Entity* contentEntity;
    Item** itemContent;
    int numContents;
    int numItemsEmitted;

public:
  QuestionBlock(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot,
                Ogre::String contentMeshName, int numContents);

  void advance(Real elapsedTime);

  void load();

  int checkCollision(Player* player);

  // Initializes one of the designated item for emission.
  // Should initialize a new instance (independent each time) so it can be repeated.
  void initItem();

  // Should start the current item moving and create another with initItem
  virtual void emitItem() = 0;

  // Blocks are not emittable from '?' blocks and don't need motion started this way.
  void initMotion() { }

  void makeEmpty();

};

#endif // #ifndef __QuestionBlock_h_
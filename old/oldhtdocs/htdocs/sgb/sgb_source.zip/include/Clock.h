#ifndef __Clock_h_
#define __Clock_h_

#include "BaseApplication.h"
#include "Item.h"

class Clock : public Item {
  int rotateSpeed;

public:
  Clock(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot);

  void advance(Real elapsedTime);

  void load();

  int checkCollision(Player* player);

  void initMotion();
};

#endif // #ifndef __Clock_h_
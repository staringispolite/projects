#ifndef __Level_h_
#define __Level_h_


#include "Aplus.h"
#include "BaseApplication.h"
#include "Block.h"
#include "ClockBlock.h"
#include "Clock.h"
#include "MtnDewBlock.h"
#include "AplusBlock.h"
#include "Enemy.h"
#include "EnemyGoomba.h" 
#include "EnemyFlyingGoomba.h"
#include "Environment.h"
#include "MtnDew.h"
#include "Object.h"
#include "Player.h"
#include "Pipe.h"
#include "Testudo.h"


class Level
{
private:
	SceneManager* mSceneMgr;
	String levelFile;
	SceneNode* levelNode;
	Environment* environment;
	Player* player;
	Enemy** enemy;
	Object** object;
	Item** item;
	Testudo* endLevel;
	Ogre::Real timeLimit;
	Ogre::Real totalElapsedTime;

	int numEnemies;
	int numObjects;
	int numItems;

	//Level Bounds (Z)
	Real leftBound;
	Real rightBound;

	bool wonLevel;
	Sound * startSound;
	Sound *jumpingSound;
	Sound *getBigSound;
	Sound *getSmallSound;
	Sound *dieSound1;
	Sound *dieSound2;
	Sound *dieSound3;
	Sound *dewSound;
	Sound *killSound1;
	Sound *killSound2;
	Sound *killSound3;
	Sound *killSound4;
	Sound *blockBreakSound;
	Sound *coinSound;
	Sound *hitSound;

public:
	int score;

 Level(SceneManager* mgrIn, String lf, String playerName, Sound *startSoundIn, 
			 Sound *jumpingSoundIn, Sound *getBigSoundIn, Sound *getSmallSoundIn, 
			 Sound *dieSound1In, Sound *dieSound2In, Sound *dieSound3In, 
			 Sound *dewSoundIn, Sound *killSound1In, Sound *killSound2In, 
			 Sound *killSound3In, Sound *killSound4In, Sound *blockBreakSoundIn,
			 Sound *coinSoundIn, Sound *hitSoundIn);
	~Level(void);

	void advance(Real elapsedTime);
	void checkCollision();
	void checkWin();
	void load();
	void loadFromFile(SceneManager* mgrIn);

	String getLevelFile();
	
	SceneNode* getNode();
	Player* getPlayer() { return player; }
	String getPlayerMesh();
	Real getLeftBound() { return leftBound; }
	Real getRightBound() { return rightBound; }
	Real getTimeLeft() { return timeLimit - totalElapsedTime; }
	bool hasWonLevel() { return wonLevel; }
};


#endif // #ifndef __World_h_
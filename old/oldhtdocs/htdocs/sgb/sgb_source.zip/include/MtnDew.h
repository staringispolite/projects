#ifndef __MtnDew_h_
#define __MtnDew_h_

#include "BaseApplication.h"
#include "Item.h"

class MtnDew : public Item {
  Vector3 initialPos;
    
public:
  MtnDew(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot);

  void advance(Real elapsedTime);

  void load();

  int checkCollision(Player* player);

  void initMotion();
};

#endif // #ifndef __MtnDew_h_
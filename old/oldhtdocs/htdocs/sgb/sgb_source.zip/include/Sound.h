#ifndef __Sound_h_
#define __Sound_h_

#include <al.h>
#include <alc.h>
//#include <al/alut.c>		Since I have not found alut.c anywhere, I suppose we use alut.h
#include <alut.h>		//Added by TheCell
//See explanation 2

class Sound 
{
	private:

		// Buffers to hold sound data.
		ALuint Buffer;

		// Sources are points of emitting sound.
		ALuint Source;


		/*
		* These are 3D cartesian vector coordinates. A structure or class would be
		* a more flexible of handling these, but for the sake of simplicity we will
		* just leave it as is.
		*/

		// Position of the source sound.
		//ALfloat SourcePos[] = { 0.0, 0.0, 0.0 };
		ALfloat SourcePos[3];

		// Velocity of the source sound.
		//ALfloat SourceVel[] = { 0.0, 0.0, 0.0 };
		ALfloat SourceVel[3];

		// Position of the Listener.
		//ALfloat ListenerPos[] = { 0.0, 0.0, 0.0 };
		ALfloat ListenerPos[3];

		// Velocity of the Listener.
		//ALfloat ListenerVel[] = { 0.0, 0.0, 0.0 };
		ALfloat ListenerVel[3];

		// Orientation of the Listener. (first 3 elements are "at", second 3 are "up")
		// Also note that these should be units of '1'.
		//ALfloat ListenerOri[] = { 0.0, 0.0, -1.0,  0.0, 1.0, 0.0 };
		ALfloat ListenerOri[6];

		ALchar * FileName;

	public:
		Sound(ALchar * FileName);
		~Sound(void);
		ALboolean LoadALData();
		void SetListenerValues();
		void KillALData();
		int Play();
		int Loop();
};

#endif // #ifndef __Sound_h_

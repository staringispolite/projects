#ifndef __Testudo_h_
#define __Testudo_h_

#include "BaseApplication.h"
#include "Item.h"
#include "Sound.h"

class Testudo : public Item {
private:
  Vector3 initialPos;
  bool bumpedAlready;
  bool bumpedDown;

public:
  Testudo(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot);

  void advance(Real elapsedTime);

  void load();

  int checkCollision(Player* player);

  // Blocks are not emittable from '?' Testudos and don't need motion started this way.
  void initMotion() { }

  bool isDown() { return bumpedDown; }

};

#endif // #ifndef __Testudo_h_
#ifndef __Enemy_h_
#define __Enemy_h_

#include "BaseApplication.h"
#include "Player.h"

class Enemy 
{
protected:
	AnimationState *mAnimationState;
	bool isAnimated;
	SceneManager* mSceneMgr;
	SceneNode* enemyNode;
	Entity* entity;

	Vector3 acc;
	Vector3 velocity;

	bool chasePlayer;
	bool isDead;
	bool toRemove;
	int deadCount;
	int enemyRadius;
	int territoryCenter;
	int territoryRange;

	bool getChasePlayer();
	void setChasePlayer(bool chase);
	void setTerritoryRange(int range);
	Sound ** killSound;

public:
Enemy();
	~Enemy(void);

	virtual void advance(Real elapsedTime) = 0;
	int checkCollision(Player *p);
	SceneNode* getNode();
	virtual void load() = 0;
	void kill();
	void squish();
	bool toDelete() {return toRemove; }
	bool isEnemyDead() {return isDead; }

};

#endif // #ifndef __Enemy_h_

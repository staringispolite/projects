#ifndef __Level_h_
#define __Level_h_


#include "BaseApplication.h"
#include "Block.h"
#include "ClockBlock.h"
#include "Enemy.h"
#include "EnemyGoomba.h"
#include "EnemyFlyingGoomba.h"
#include "Environment.h"
#include "Object.h"
#include "Player.h"


class Level
{
private:
	SceneManager* mSceneMgr;
	SceneNode* levelNode;
	Environment* environment;
	Enemy** enemy;
	Object** object;
  Item** item;

	int numEnemies;
	int numObjects;
  int numItems;

public:
	int score;
	Level(SceneManager*);
	~Level(void);

	void loadFromFile(SceneManager* mgrIn);
	void advance(Real elapsedTime);
	void load();
	SceneNode* getNode();
	void checkCollision(Player* player);

};


#endif // #ifndef __World_h_
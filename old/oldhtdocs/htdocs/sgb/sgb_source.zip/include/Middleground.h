#ifndef __Middleground_h_
#define __Middleground_h_


#include "BaseApplication.h"



class Middleground
{
private:
	SceneManager* mSceneMgr;
	SceneNode* node;
	Entity * entity;

public:
	Middleground(SceneManager*);
	~Middleground(void);

	void load();
	SceneNode* getNode();

};


#endif // #ifndef __Middleground_h_
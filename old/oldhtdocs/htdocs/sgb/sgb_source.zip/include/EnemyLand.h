#ifndef __Enemy_Land_h_
#define __Enemy_Land_h_

#include "Enemy.h"

class EnemyLand : public Enemy
{
public:

	EnemyLand();
	void advance(Real elapsedTime);
};

#endif // #ifndef __Enemy_Land_h_

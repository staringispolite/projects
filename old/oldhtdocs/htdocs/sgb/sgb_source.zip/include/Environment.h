#ifndef __Environment_h_
#define __Environment_h_


#include "BaseApplication.h"
#include "Foreground.h"
#include "Middleground.h"
#include "Background.h"


class Environment
{
private:
	SceneManager* mSceneMgr;
	SceneNode* node;

    Foreground* foreground;
    Middleground* middleground;
    Background* background;

public:
	Environment(SceneManager*);
	~Environment(void);

	void load();
	SceneNode* getNode();

};


#endif // #ifndef __Environment_h_
#ifndef __Background_h_
#define __Background_h_


#include "BaseApplication.h"



class Background
{
private:
	SceneManager* mSceneMgr;
	SceneNode* node;
	Entity * entity;

public:
	Background(SceneManager*);
	~Background(void);

	void load();
	SceneNode* getNode();

};


#endif // #ifndef __Middleground_h_
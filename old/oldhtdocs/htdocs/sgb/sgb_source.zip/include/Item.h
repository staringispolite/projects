#ifndef __Item_h_
#define __Item_h_

#include "BaseApplication.h"
#include "Player.h"

class Item {
protected:
	AnimationState *mAnimationState;
	bool isAnimated;
	SceneManager* mSceneMgr;
	SceneNode* itemNode;
	Entity* entity;

  // Position stored indirectly by translating itemNode
  // or via itemNode->getWorldPosition().
  Vector3 velocity;
	Vector3 acc;

  // Visibility control for use in '?' boxes.
  bool visible;

  // There are static items and that that move (ie. pop out of '?' boxes)
  bool moving;

  // Collision detection.
 	int itemRadius;


public:
	Item();
	~Item(void);

	virtual void advance(Real elapsedTime) = 0;
	virtual int checkCollision(Player *p);
	SceneNode* getNode();
	virtual void load() = 0;
  int getItemRadius() { return itemRadius; }
  void hit();
  void setVisible(bool vis);
  void setMoving(bool moving);
  virtual void initMotion() = 0;
};

#endif // #ifndef __Item_h_

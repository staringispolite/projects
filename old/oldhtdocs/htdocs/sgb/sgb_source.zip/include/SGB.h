/*
-----------------------------------------------------------------------------
This source file is part of OGRE
(Object-oriented Graphics Rendering Engine)
For the latest info, see http://www.ogre3d.org/

Copyright (c) 2000-2005 The OGRE Team
Also see acknowledgements in Readme.html

You may use this sample code for anything you like, it is not covered by the
LGPL like the rest of the engine.
-----------------------------------------------------------------------------
*/

/*
-----------------------------------------------------------------------------
Filename:    SGB.h
Description: A place for me to try out stuff with OGRE.
-----------------------------------------------------------------------------
*/
#ifndef __SGB_h_
#define __SGB_h_


#include "BaseApplication.h"
#include "World.h"



class SGBApp : public BaseApplication
{
public:


	SGBApp(void);
	virtual ~SGBApp(void);
	virtual bool frameStarted(const FrameEvent& evt);
	virtual bool processUnbufferedKeyInput(const FrameEvent& evt);
	virtual void moveCamera();
	virtual void updateStats(void);

	Vector3 cameraMovement();

protected:
	virtual void createScene(void);

private:
	World* world;
	Vector3 camLocal;
	Vector3 lookAtVector;
	bool firsttime;
	OverlayManager* overlayMgr;
	Sound * backgroundSound;

	KeyCode keyDown;				// The key being held down. Used to make sure a key is released before processing.
	bool mainMenu;					// Whether the main menu screen is open
	bool pause;						// Whether the pause menu is open

	String* characters;
	String* characterNames;
	String* levels;					// List of loaded level files
	String* levelNames;				// List of loaded level names
	int numCharacters;				// Number of characters
	int numLevels;					// Number of levels
	int currCharacter;				// The current character
	int currLevel;					// The current level

	void loadCharacters();
	void loadLevels();
	void menuChangeCharacter();
	void menuChangeLevel();
	void toggleMainMenu();
	void togglePause();
};


#endif // #ifndef __SGB_h_
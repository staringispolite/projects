#ifndef __Block_h_
#define __Block_h_

#include "BaseApplication.h"
#include "Item.h"
#include "Sound.h"

class Block : public Item {
private:
  Vector3 initialPos;
  bool bumpedAlready;
  Sound * blockBreakSound;

public:
  Block(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot, Sound *blockBreakSoundIn);
  ~Block();

  void advance(Real elapsedTime);

  void load();

  int checkCollision(Player* player);

  // Blocks are not emittable from '?' blocks and don't need motion started this way.
  void initMotion() { }

};

#endif // #ifndef __Block_h_
#ifndef __ClockBlock_h_
#define __ClockBLock_h_

#include "QuestionBlock.h"

class ClockBlock : public QuestionBlock {

private:
	Sound * coinSound;

public:
  ClockBlock::ClockBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn, Sound *coinSoundIn);

  ~ClockBlock();

  void emitItem();

  void load();
};

#endif
#ifndef __Object_h_
#define __Object_h_


#include "BaseApplication.h"
#include "Environment.h"
#include "Enemy.h"




class Object
{
private:
	SceneManager* mSceneMgr;
	SceneNode* node;

public:
	Object(SceneManager*);
	~Object(void);

	void load();
	SceneNode* getNode();

};


#endif // #ifndef __Object_h_
#ifndef __AplusBlock_h_
#define __AplusBLock_h_

#include "QuestionBlock.h"
#include "Sound.h"

class AplusBlock : public QuestionBlock {

private:
	Sound * hitSound;
public:
  AplusBlock::AplusBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn, Sound *hitSoundIn);

  ~AplusBlock();
  void emitItem();

  void load();
};

#endif
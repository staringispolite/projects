#ifndef __Enemy_Air_h_
#define __Enemy_Air_h_

#include "Enemy.h"

class EnemyAir : public Enemy
{
protected:
	bool oscillate;
	int oscillateCounter;  // for simulating an ememy floating in waves

public:
	EnemyAir();
	void advance(Real elapsedTime);
	void setOscillation(bool yorn);
};

#endif // #ifndef __Enemy_Air_h_

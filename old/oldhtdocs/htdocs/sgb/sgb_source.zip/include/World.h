#ifndef __World_h_
#define __World_h_


#include "BaseApplication.h"
#include "Player.h"
#include "Level.h"



class World
{
public:
	SceneManager* mSceneMgr;
	//UI layer
	//Sound
	Sound *startSound;
	Sound *jumpingSound;
	Sound *getSmallSound;
	Sound *getBigSound;
	Sound *dieSound1;
	Sound *dieSound2;
	Sound *dieSound3;
	Sound *dewSound;
	Sound *killSound1;
	Sound *killSound2;
	Sound *killSound3;
	Sound *killSound4;
	Sound *blockBreakSound;
	Sound *coinSound;
	Sound *hitSound;
	//Physics
	Level* level;
	int score;
	bool reseting;
	World(SceneManager*);
	~World(void);
	void load(String,String);
	void reset();
	void checkCollision();
  Level* getLevel() { return level; }
};


#endif // #ifndef __World_h_
#ifndef __MtnDewBlock_h_
#define __MtnDewBLock_h_

#include "QuestionBlock.h"

class MtnDewBlock : public QuestionBlock {

public:
  MtnDewBlock::MtnDewBlock(Ogre::SceneManager *mgrIn, Ogre::String name, 
             Ogre::Vector3 initialPos, Ogre::Quaternion initialRot,
             Ogre::String contentMeshName, int numContentsIn);

  void emitItem();

  void load();
};

#endif
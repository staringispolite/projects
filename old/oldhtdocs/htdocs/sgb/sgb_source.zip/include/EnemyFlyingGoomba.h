#ifndef __Enemy_Flying_Goomba_h_
#define __Enemy_Flying_Goomba_h_

#include "EnemyAir.h"

class EnemyFlyingGoomba : public EnemyAir
{
public:
	EnemyFlyingGoomba(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRotSound, Sound *killSound1In, Sound *killSound2In, Sound *killSound3In, Sound *killSound4In);
	void load();
};

#endif // #ifndef __Enemy_Flying_Goomba_h_

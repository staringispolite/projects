#ifndef __Pipe_h_
#define __Pipe_h_

#include "BaseApplication.h"
#include "Item.h"

class Pipe : public Item {
private:
  Vector3 initialPos;
  bool bumpedAlready;
  SceneNode* itemNodeTop;
  Entity* entityTop;

public:
  Pipe(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot, int scale);

  void advance(Real elapsedTime);

  void load();

  int checkCollision(Player* player);

  // Pipes are not emittable from '?' blocks and don't need motion started this way.
  void initMotion() { }

};

#endif // #ifndef __Pipe_h_
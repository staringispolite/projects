#ifndef __Foreground_h_
#define __Foreground_h_


#include "BaseApplication.h"



class Foreground
{
private:
	SceneManager* mSceneMgr;
	SceneNode* node;
	Entity * entity;


public:
	Foreground(SceneManager*);
	~Foreground(void);

	void load();
	SceneNode* getNode();

};


#endif // #ifndef __Foreground_h_
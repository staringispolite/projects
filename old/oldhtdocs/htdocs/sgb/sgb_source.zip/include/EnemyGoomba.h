#ifndef __Enemy_Goomba_h_
#define __Enemy_Goomba_h_

#include "EnemyLand.h"

class EnemyGoomba : public EnemyLand
{
public:

   EnemyGoomba(SceneManager* mgrIn, String name, Vector3 initialPos, Quaternion initialRot, Sound *killSound1In, Sound *killSound2In, Sound *killSound3In, Sound *killSound4In);
	void load(); 

};

#endif // #ifndef __Enemy_Goomba_h_

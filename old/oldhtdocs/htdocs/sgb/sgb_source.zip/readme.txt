Super Graphics Bros. Team
Games Programming
Prof. Mount
Beta Release - 12/19/06


Find out more on the Official Website: http://www.wam.umd.edu/~jhoward/sgb/index.html


Install Steps:

0) Install the Ogre SDK for Visual Studio 2005 (Full or Express) (http://www.ogre3d.org/index.php?option=com_remository&Itemid=57&func=fileinfo&filecatid=42&parent=category)
1) Unzip this source into your desired directory
2) Open up the Visual Studio 2005 solution file provided.
3) Set the working directory by doing the following:
	- Go to Project -> SGB Properties
	- Select "Debugging" under "Configuration Properties"
	- Set "working directory" to "bin\$(ConfigurationName)"
4) Compile and Run the project in Debug mode.
5) Gameplay:
	Use the arrow keys to walk
	Hold the Shift key while pressing left or right to run
	Press the space bar to jump
	If you don't jump on top of the goomba's, you will be killed and the game will exit.